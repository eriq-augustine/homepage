#ifndef ICECREAM_H
#define ICECREAM_H

struct ice_cream {
   char flavor;
   int melted;
   double mass;
   char container;
};

struct ice_cream create_ice_cream(char flavor, int melted, double mass, char container);
int get_by_flavor(struct ice_cream const input[], int size, struct ice_cream result[], char flavor);

void print_icecream(struct ice_cream ice);
void print_alls(struct ice_cream const input[], int size);

double total_mass(struct ice_cream const input[], int size);

// Return te index of the icecream with the lowest flavor.
int lowest_flavor(struct ice_cream const input[], int size);

#endif
