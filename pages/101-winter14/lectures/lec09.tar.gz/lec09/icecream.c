/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "icecream.h"


int main(int argc, char *argv[])
{
   // p == 'pool'
   struct ice_cream ices[] = {
      create_ice_cream('s', 0, 20, 'p'),
      create_ice_cream('c', 0, 5, 'b'),
      create_ice_cream('v', 0, 14, 'f'),
      create_ice_cream('c', 0, 3, 'c'),
      create_ice_cream('v', 0, 7, 'B'),
      create_ice_cream('C', 0, 1.2, 's')
   };

   print_alls(ices, 6);

   struct ice_cream results[6];
   int num_results = get_by_flavor(ices, 6, results, 'c');
   print_alls(results, num_results);

   printf("Total Mass (ALL): %f\n", total_mass(ices, 6));
   printf("Total Mass (c): %f\n", total_mass(results, num_results));

   int lowest = lowest_flavor(ices, 6);
   if (lowest == -1) {
      printf("No lowest!\n");
   } else {
      print_icecream(ices[lowest]);
   }

   lowest = lowest_flavor(ices, 0);
   if (lowest == -1) {
      printf("No lowest!\n");
   } else {
      print_icecream(ices[lowest]);
   }

   return EXIT_SUCCESS;
}

struct ice_cream create_ice_cream(char flavor, int melted, double mass, char container) {
   struct ice_cream iceice = {flavor, melted, mass, container};
   return iceice;
}

int get_by_flavor(struct ice_cream const input[], int size, struct ice_cream result[], char flavor) {
   int i;
   int count = 0;

   for (i = 0; i < size; i++) {
      if (input[i].flavor == flavor) {
         result[count++] = input[i];
      }
   }

   return count;
}

void print_icecream(struct ice_cream ice) {
   printf("%c, %d, %f, %c\n", ice.flavor, ice.melted, ice.mass, ice.container);
}

void print_alls(struct ice_cream const input[], int size) {
   int i;

   // Can't change a const!
   // input[0] = create_ice_cream('g', 1, 0.001, 't');

   for (i = 0; i < size; i++) {
      print_icecream(input[i]);
   }

   printf("----------------\n");
}

double total_mass(struct ice_cream const input[], int size) {
   int i;
   double mass = 0;

   for (i = 0; i < size; i++) {
      mass += input[i].mass;
   }

   return mass;
}

int lowest_flavor(struct ice_cream const input[], int size) {
   int i;
   int current_lowest_index = -1;

   for (i = 0; i < size; i++) {
      // If first time, or lowest.
      if (current_lowest_index == -1 || input[i].flavor < input[current_lowest_index].flavor) {
         current_lowest_index = i;
      }
   }

   return current_lowest_index;
}
