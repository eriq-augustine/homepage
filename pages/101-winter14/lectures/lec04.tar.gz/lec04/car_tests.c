/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "car.h"
#include "checkit.h"

void test_cases() {
   struct engine v8 = create_engine(8, 6, 30);
   struct engine v6 = create_engine(6, 4, 20);

   checkit_int(v8.horsepower > v6.horsepower, 1);

   struct car lambo = create_car(4, 15, 2, create_engine(12, 8, 300));
   checkit_int(lambo.engy.horsepower, 300);

   lambo = tune_up(lambo);
   checkit_int(lambo.engy.horsepower > 300, 1);

   checkit_int(is_more_powerful(lambo, create_car(5, 25, 5, create_engine(12, -1, 2))), 1);
}

int main(int argc, char *argv[])
{
   test_cases();
   return EXIT_SUCCESS;
}
