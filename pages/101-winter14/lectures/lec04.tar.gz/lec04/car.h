#ifndef CAR_H
#define CAR_H


struct engine {
   int cylinders;
   double disp;
   int horsepower;
};

struct car {
   int wheels;
   double mpg;
   int capacity;

   struct engine engy;
};

struct engine create_engine(int, double, int);
struct car create_car(int, double, int, struct engine);

struct car tune_up(struct car);

int is_more_powerful(struct car car_1, struct car car_2);

#endif
