#ifndef GARAGE_H
#define GARAGE_H

#include "car.h"

struct garage {
   struct car ashsadhdsa;
};

struct garage create_garage();

#endif
