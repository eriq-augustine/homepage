/**
 *  @author Eric Augustine
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "cast.h"
#include "data.h"

void print_image(double min_x, double max_x,
                 double min_y, double max_y,
                 int width, int height,
                 struct point eye,
                 struct sphere spheres[], int num_spheres) {
   printf("P3\n");
   printf("%d %d\n", width, height);
   printf("255\n");
   cast_all_rays(min_x, max_x,
                 min_y, max_y,
                 width, height,
                 eye,
                 spheres, num_spheres);
}

int main(int argc, char *argv[]) {
   double min_x = -10;
   double max_x = 10;

   double min_y = -10;
   double max_y = 10;

   int width = 1024;
   int height = 1024;

   struct point eye = create_point(0, 0, -200);

   struct sphere spheres[] = {create_sphere(create_point(0, 0, 0), 2, create_color(0, 0, 0)),
                              create_sphere(create_point(5, 5, -5), 2, create_color(1, 0, 0)),
                              create_sphere(create_point(-5, 5, -10), 2, create_color(0, 0, 1)),
                              create_sphere(create_point(-5, -5, -15), 2, create_color(0, 1, 0)),
                              create_sphere(create_point(5, -5, -20), 2, create_color(1, 0, 1))};

   print_image(min_x, max_x,
               min_y, max_y,
               width, height,
               eye,
               spheres, 5);

   return EXIT_SUCCESS;
}
