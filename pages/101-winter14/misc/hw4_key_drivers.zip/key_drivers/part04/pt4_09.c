/**
 *  @author Eric Augustine
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "cast.h"
#include "data.h"

void print_image(double min_x, double max_x,
                 double min_y, double max_y,
                 int width, int height,
                 struct point eye,
                 struct sphere spheres[], int num_spheres,
                 struct color amb_light,
                 struct light light_source) {
   printf("P3\n");
   printf("%d %d\n", width, height);
   printf("255\n");
   cast_all_rays(min_x, max_x,
                 min_y, max_y,
                 width, height,
                 eye,
                 spheres, num_spheres,
                 amb_light,
                 light_source);
}

int main(int argc, char *argv[]) {
   double min_x = -10;
   double max_x = 10;

   double min_y = -10;
   double max_y = 10;

   int width = 1024;
   int height = 1024;

   struct color amb_light = create_color(1, 1, 1);
   struct light light_source = create_light(create_point(-100.0, 100.0, -100.0), create_color(1.5, 1.5, 1.5));

   struct point eye = create_point(0, 0, -200);

   struct sphere spheres[] = {
      create_sphere(create_point(0, 0, 0),
                    2,
                    create_color(0, 0, 0),
                    create_finish(0.2, 0.4)),
      create_sphere(create_point(8, 8, -5),
                    2,
                    create_color(1, 0, 0),
                    create_finish(0.2, 0.4)),
      create_sphere(create_point(-8, 8, -10),
                    2,
                    create_color(0, 0, 1),
                    create_finish(0.2, 0.4)),
      create_sphere(create_point(-8, -8, -15),
                    2,
                    create_color(0, 1, 0),
                    create_finish(0.2, 0.4)),
      create_sphere(create_point(8, -8, -20),
                    2,
                    create_color(1, 0, 1),
                    create_finish(0.2, 0.4))
   };

   print_image(min_x, max_x,
               min_y, max_y,
               width, height,
               eye,
               spheres, 5,
               amb_light,
               light_source);

   return EXIT_SUCCESS;
}
