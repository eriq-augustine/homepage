To run Toleco use "java -jar Toleco.jar"
