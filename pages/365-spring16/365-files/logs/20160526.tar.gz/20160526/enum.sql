DROP TABLE IF EXISTS EnumTest;
CREATE TABLE EnumTest (
   id INT PRIMARY KEY AUTO_INCREMENT,
   val ENUM('a', 'b', 'c')
);

INSERT INTO EnumTest (val) VALUES ('a'), ('b'), ('c');

-- no error, only warning
INSERT INTO EnumTest (val) VALUES ('d');
SHOW WARNINGS;

-- Can reference enum by index.
-- Index starts at 1.
INSERT INTO EnumTest (val) VALUES (1);

-- warning
INSERT INTO EnumTest (val) VALUES (0);
SHOW WARNINGS;

-- can treat it as a string
SELECT val, LENGTH(val), CONCAT('Enum: ', val) FROM EnumTest;

-- if a number is required, the index value is used.
SELECT val + 0, val + 1, SIN(val), POW(2, val) FROM  EnumTest;

-- aggregates are more ambiguious because some can take strings.
-- the string value is always favored over the index value.
SELECT MIN(val), MAX(val), AVG(val) FROM EnumTest;
