This is an informal lecture dedicated to different tips and tricks that the students should know.

Things to cover:
   - Batch Insert
   - Different Insert Types
      - Normal
      - Replace
      - Insert Ignore
      - Upsert
   - Auto Increment
   - Enums
   - LIMIT
      - Proper Min/Max
      - Paging
   - mysqldump
