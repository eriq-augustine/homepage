DROP TABLE IF EXISTS AutoTest;
CREATE TABLE AutoTest (
   id INT PRIMARY KEY AUTO_INCREMENT,
   letter CHAR(1) NOT NULL
);

-- 1, 2, 3
INSERT INTO AutoTest VALUES (NULL, 'a'), (NULL, 'b'), (NULL, 'c');

-- 4
INSERT INTO AutoTest
   (letter)
VALUES
   ('d');

-- 10
INSERT INTO AutoTest
   (id, letter)
VALUES
   (10, 'e');

-- 11
INSERT INTO AutoTest
   (letter)
VALUES
   ('f');

DELETE FROM AutoTest;
-- 12, 13
INSERT INTO AutoTest VALUES (NULL, 'a'), (NULL, 'e');

SHOW CREATE TABLE AutoTest;
