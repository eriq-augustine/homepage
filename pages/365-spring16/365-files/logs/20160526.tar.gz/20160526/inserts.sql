-- Word counts

DROP TABLE IF EXISTS InsertTest;
CREATE TABLE InsertTest (
   id INT PRIMARY KEY,
   count INT NOT NULL
);

INSERT INTO InsertTest VALUES (1, 1), (2, 1);

-- error and fail
INSERT INTO InsertTest VALUES (1, 2), (3, 1);

-- not error, but fail to update 1. 3 is inserted.
INSERT IGNORE INTO InsertTest VALUES (1, 2), (3, 1);

-- succeed
REPLACE INTO InsertTest VALUES (1, 2), (3, 2);

-- single upsert
-- Problem: very specific to 'a'.
INSERT INTO InsertTest VALUES (1, 3)
ON DUPLICATE KEY UPDATE count = 3;

-- multiple upsert
INSERT INTO InsertTest VALUES (1, 1), (2, 1), (3, 1), (4, 1)
ON DUPLICATE KEY UPDATE count = count + 1;

-- multiple upsert using VALUES
INSERT INTO InsertTest VALUES (1, 1), (2, 2), (3, 3), (4, 4), (5, 1)
ON DUPLICATE KEY UPDATE count = count + VALUES(count);

-- Insert if not exists that works for all SQL.
INSERT INTO InsertTest
SELECT 6, 1
FROM (
   SELECT *
   FROM (SELECT 1) XX
   WHERE NOT EXISTS (
      SELECT *
      FROM InsertTest
      WHERE id = 6
   )
) X
;
