CREATE TABLE DateTest (
   timeCol TIME,
   dateCol DATE,
   dateTimeCol DATETIME,
   timeStampCol TIMESTAMP
);

INSERT INTO DateTest
VALUES
   (NOW(), NOW(), NOW(), NOW())
;
