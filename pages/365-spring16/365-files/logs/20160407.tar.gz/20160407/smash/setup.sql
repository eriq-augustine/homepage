source create.sql
source insertMoves.sql
source insertChars.sql
