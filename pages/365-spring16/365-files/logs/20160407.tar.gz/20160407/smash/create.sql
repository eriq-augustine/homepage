DROP TABLE IF EXISTS Characters;
DROP TABLE IF EXISTS MoveSets;

CREATE TABLE MoveSets (
   id INT,
   input VARCHAR(16),
   name VARCHAR(256),
   percent VARCHAR(64),
   UNIQUE(id, input)
);

CREATE TABLE Characters (
   name VARCHAR(32),
   weight INT NOT NULL,
   fallSpeed FLOAT NULL,
   moveSet INT REFERENCES MoveSets(id),
   image BLOB,
   CONSTRAINT Necessary PRIMARY KEY (name)
);
