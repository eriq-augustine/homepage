import java.io.File;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class HangmanGame {
   private static final String DICTIONARY = "words.txt";
   private static final int NUM_TRIES = 10;

   private static List<String> words = getWords(DICTIONARY);

   private static List<String> getWords(String dict) {
      List<String> newWords = new ArrayList<String>();

      try {
         Scanner scanner = new Scanner(new File(DICTIONARY));
         while (scanner.hasNext()) {
            newWords.add(scanner.next().trim().toLowerCase());
         }
      } catch (Exception ex) {
         // Shhhhhhhh, don't worry about it...
      }

      return newWords;
   }

   private int attempts;
   private boolean[] guesses;

   private String word;

   public HangmanGame() {
      attempts = 0;
      guesses = new boolean['z' - 'a' + 1];
      word = pickWord();
   }

   private String pickWord() {
      Random rand = new Random();
      return words.get(rand.nextInt(words.size()));
   }

   public String getWord() {
      return word;
   }

   public boolean guess(char letter) {
      if (attempts == NUM_TRIES) {
         throw new IllegalStateException("Game is over");
      }

      if (letter < 'a' || letter > 'z') {
         throw new IllegalArgumentException("Guess not in bounds");
      }

      int guessIndex = (int)(letter - 'a');
      if (guesses[guessIndex]) {
         throw new IllegalStateException("You already guessed this letter");
      }

      guesses[guessIndex] = true;

      if (word.indexOf(letter) == -1) {
         attempts += 1;
         return false;
      }

      return true;
   }

   public boolean done() {
      return win() || attempts >= NUM_TRIES;
   }

   public boolean win() {
      return !toString().contains("_");
   }

   public String toString() {
      String rtn = "";

      for (int i = 0; i < word.length(); i++) {
         if (guesses[word.charAt(i) - 'a']) {
            rtn += " " + word.charAt(i) + " ";
         } else {
            rtn += " _ ";
         }
      }

      return rtn;
   }
}
