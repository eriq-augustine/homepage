import java.util.Scanner;

public class PlayerDriver {
   public static void main(String[] args) {
      HangmanGame game = new HangmanGame();

      System.out.println("Let's Play some hangman!");

      while (!game.done()) {
         System.out.println(game);
         char guess = getLetter();

         try {
            game.guess(guess);
         } catch (Exception ex) {
            System.out.println("God!!>!>!>.... Making me look like an idiot. Play right!!!");
            System.out.println(ex);
         }

         if (game.done()) {
            System.out.println("Game is done!");

            if (game.win()) {
               System.out.println("You WONN!!N!NN!N!N!!!!!");
            } else {
               System.out.println("hahaha, you lost");
               System.out.println("The word was: " + game.getWord());
            }
         }

         System.out.println();
      }

      System.out.println(game);
   }

   // Assumes good input will break if nothing.
   public static char getLetter() {
      System.out.print("Give me a letter and don't mess around!: ");
      Scanner scanner = new Scanner(System.in);
      return scanner.next().charAt(0);
   }
}
