public class Chair {
   private String name;

   public Chair(String myName) {
      name = myName;
   }
}
