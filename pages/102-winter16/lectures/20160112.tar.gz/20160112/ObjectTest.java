public class ObjectTest {
   public static void main(String[] args) {
      String str = "Hey, friend";
      int myInt = 4;

      System.out.println(str.toString());
      System.out.println(str);

      // System.out.println(myInt.toString()); // Can't do, int is not an object.
      System.out.println(myInt);

      Object obj = new Object();
      System.out.println(obj.toString());
      System.out.println(obj);

      // String str2 = "Some String"; // Not equals
      String str2 = "Hey, friend";
      if (str.equals(str2)) {
         System.out.println("(equals) Awww yeah");
      } else {
         System.out.println("(eqauls) toast...");
      }

      if (str == str2) { // Bad Java practice, don't do it.
         System.out.println("(==) Awww yeah");
      } else {
         System.out.println("(==) toast...");
      }

      Chair chair1 = new Chair("Jeffery");
      // Chair chair2 = new Chair("Geofery"); // Different
      // Chair chair2 = new Chair("Jeffery"); // Different (uses Object.equals()
      Chair chair2 = chair1;
      if (chair1.equals(chair2)) {
         System.out.println("Chairs are the same");
      } else {
         System.out.println("Chairs are different!");
      }
   }
}
