public abstract class Organism {
   private String name;
   private double mass;

   public Organism(String name, double mass) {
      this.name = name;
      this.mass = mass;
   }

   public boolean equals(Object other) {
      if (other == null) {
         return false;
      }

      if (!this.getClass().equals(other.getClass())) {
         return false;
      }

      Organism otherOrganism = (Organism)other;
      return mass == otherOrganism.mass && name.equals(otherOrganism.name);
   }
}
