public abstract class Plant extends Organism {
   private boolean hasLeaves;

   public Plant(String name, double mass, boolean hasLeaves) {
      super(name, mass);
      this.hasLeaves = hasLeaves;
   }

   public boolean equals(Object other) {
      // Get null, class, Ogranism's privates checked for free.
      if (!super.equals(other)) {
         return false;
      }

      return hasLeaves == ((Plant)other).hasLeaves;
   }
}
