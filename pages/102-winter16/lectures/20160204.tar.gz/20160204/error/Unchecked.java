public class Unchecked {
   public static void main(String[] args) {
      Unchecked unchecked = new Unchecked();

      unchecked.doIt(0);

      try {
         unchecked.doIt(-1);
      } catch (IllegalArgumentException ex) {
         System.out.println("Caught in main");
         System.out.println(ex);
         ex.printStackTrace();
      }
   }

   /**
    * @throws IllegalArgumentException If num < 0
    */
   public void doIt(int num) {
      if (num < 0) {
         throw new IllegalArgumentException();
      }
   }
}
