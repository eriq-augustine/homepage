public class Checked {
   public static void main(String[] args) {
      Checked checked = new Checked();

      // Must catch
      try {
         checked.doIt2();
      } catch (java.io.FileNotFoundException ex) {
         System.out.println("Caught in main");
         System.out.println(ex);
         ex.printStackTrace();
      }
   }

   // Must catch it...
   public void doIt() {
      try {
         throw new java.io.FileNotFoundException("Checked");
      } catch (java.io.FileNotFoundException ex) {
         System.out.println("Caught");
      }
   }

   // ... or declared thrown.
   public void doIt2() throws java.io.FileNotFoundException {
      throw new java.io.FileNotFoundException("Checked");
   }
}
