public class Finally {
   public static void main(String[] args) {
      /*
      try {
         System.out.println("Try");
         doIt();
         System.out.println("Won't get here");
      } catch (IllegalArgumentException ex) {
         System.out.println("Catch");
         return;
      } finally {
         // Will ALWAYS GET RUN!!!
         System.out.println("Finally");
         return;
      }
      */

      System.out.println(returnIt());
   }

   public static int returnIt() {
      try {
         System.out.println("Try");
         doIt();
         System.out.println("Won't get here");
      } catch (IllegalArgumentException ex) {
         System.out.println("Catch");
         return 1;
      } finally {
         // Will ALWAYS GET RUN!!!
         System.out.println("Finally");
         return 2;
      }
   }

   public static void doIt() {
      throw new IllegalArgumentException();
   }
}
