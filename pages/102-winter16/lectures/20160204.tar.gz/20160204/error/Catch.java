public class Catch {
   public static void main(String[] args) {
      try {
         // doIt(-1);

         doIt(1);
      } catch (NullPointerException ex) {
         // Never get here!
         System.out.println("Null");
         ex.printStackTrace();
      } catch (IllegalArgumentException clown) {
         System.out.println("Illegal Argument");
         clown.printStackTrace();
      } catch (Exception ex) {
         System.out.println("Exception: Everything");
         ex.printStackTrace();
      }
   }

   public static void doIt(int i) throws Exception {
      if (i < 0) {
         throw new IllegalArgumentException("Less than");
      }

      if (i > 0) {
         throw new IndexOutOfBoundsException("Greater Than");
      }

      throw new Exception();
   }
}
