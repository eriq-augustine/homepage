public class LinkedList<E> {
   private Node head;
   private int size;

   public static void main(String[] args) {
      LinkedList<String> list = new LinkedList<String>();
      list.add("One");
      list.add("Two");
      list.add("Three");
      list.add("Four");
      list.add("Five");

      for (int i = 0; i < list.size(); i++) {
         System.out.println(list.get(i));
      }
   }

   public LinkedList() {
      head = null;
      size = 0;
   }

   public void add(E something) {
      size++;

      if (head == null) {
         head = new Node(something);
         return;
      }

      Node current = head;
      while (current.next != null) {
         current = current.next;
      }

      current.next = new Node(something);
   }

   public E get(int index) {
      if (index < 0 || index >= size) {
         throw new IndexOutOfBoundsException();
      }

      Node current = head;
      for (int i = 0; i < index; i++) {
         current = current.next;
      }

      return current.data;
   }

   public int size() {
      return size;
   }

   // Don't do this!
   // private class Node<E> {
   private class Node {
      public E data;
      public Node next;

      public Node(E data) {
         this.data = data;
         next = null;
      }
   }
}
