import java.util.Arrays;

public class ReverseSort<E extends Comparable<E>> implements Comparable<ReverseSort<E>> {
   private E data;
   private static final int SIZE = 3;

   public static void main(String[] args) {
      String[] arr = new String[SIZE];
      // ReverseSort<String> arr = new ReverseSort<String>[SIZE]; // Error
      // Give a warning.
      ReverseSort<String>[] arr2 = new ReverseSort[SIZE];

      for (int i = 0; i < SIZE; i++) {
         String val = "" + Math.random();
         arr[i] = val;
         arr2[i] = new ReverseSort<String>(val);
      }

      System.out.println(Arrays.toString(arr));
      System.out.println(Arrays.toString(arr2));

      Arrays.sort(arr);
      Arrays.sort(arr2);

      System.out.println(Arrays.toString(arr));
      System.out.println(Arrays.toString(arr2));
   }

   public ReverseSort(E data) {
      this.data = data;
   }

   public String toString() {
      return data.toString();
   }

   public int compareTo(ReverseSort<E> other) {
      return -1 * data.compareTo(other.data);
   }
}
