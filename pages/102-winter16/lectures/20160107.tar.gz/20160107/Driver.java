public class Driver {
   public static void main(String[] args) {
      System.out.println("Drive some ducks!");

      Duck.waddle();

      System.out.println("Am I a duck: " + amIADuck());
      System.out.println("Is Duck a duck: " + Duck.amIADuck());

      // make me a duck
      Duck donald = new Duck("Donald");
      donald.quack();

      Duck daisy = new Duck("Daisy");
      daisy.quack();

      int a = 1;
      // String a = "one"; // No good, already defined a.
      // a = "One"; // No good, a is int.
      String b = "One";
   }

   public static boolean amIADuck() {
      return false;
   }
}
