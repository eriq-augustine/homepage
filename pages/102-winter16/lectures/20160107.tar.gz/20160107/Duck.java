public class Duck {
   private String name;

   public static void main(String[] args) {
      System.out.println("Quack, I'm a duck");

      // quack(); // No good, need an object.
      Duck duck1 = new Duck("quacky");
      duck1.quack();
   }

   public static void waddle() {
      System.out.println("Waddle Waddle");
   }

   public static boolean amIADuck() {
      return true;
   }

   // Constructor
   public Duck(String myName) {
      name = myName;
   }

   public void quack() {
      System.out.println("Quack: " + name);
   }
}

// System.out.println("I can't do this");
