import java.util.ArrayList;
import java.util.List;

public class Driver {
   public static void main(String[] args) {
      List<SomeStatic> list = new ArrayList<SomeStatic>();

      System.out.println("Foo: " + SomeStatic.getFoo());

      for (int i = 0; i < 7; i++) {
         SomeStatic clown = new SomeStatic("Randy (" + i + ")");
         // This is strange.
         System.out.println("" + clown + ": " + clown.getFoo());

         list.add(clown);
      }

      System.out.println("Foo: " + SomeStatic.getFoo());

      for (SomeStatic clown : list) {
         System.out.println("" + clown + ": " + clown.getFoo());
      }
   }
}
