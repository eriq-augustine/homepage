public class SomeStatic {
   private static int foo = 0;

   // This should be static!
   // private int foo = 0;

   // This should be non-static.
   private String name;
   // private static String name;

   public SomeStatic(String name) {
      this.name = name;
      foo++;
   }

   // This should be static.
   public static int getFoo() {
   // public int getFoo() {
      return foo;
   }

   public String toString() {
      return name;
   }
}
