import java.util.ArrayList;
import java.util.List;

public class DeepDriver {
   public static void main(String[] args) {
      List<Integer> list1 = new ArrayList<Integer>();
      list1.add(new Integer(1));

      List<Integer> list2 = new ArrayList<Integer>();
      list2.add(new Integer(2));
      list2.add(new Integer(3));

      Deep s1 = new Deep(list1);
      // Deep s2 = new Deep(list2);
      Deep s2 = s1.copy();

      s2.getMyInts().add(new Integer(4));
      s2.getMyInts().add(new Integer(54));

      System.out.println(s1);
      System.out.println(s2);
   }
}
