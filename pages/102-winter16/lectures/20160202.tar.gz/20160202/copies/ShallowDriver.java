public class ShallowDriver {
   public static void main(String[] args) {
      Shallow s1 = new Shallow(1);
      // Shallow s2 = new Shallow(2);
      Shallow s2 = s1.copy();

      s1.setMyInt(10);

      System.out.println(s1.getMyInt());
      System.out.println(s2.getMyInt());
   }
}
