import java.util.ArrayList;
import java.util.List;

public class Deep {
   private List<Integer> myInts;

   public Deep(List<Integer> myInts) {
      this.myInts = myInts;
   }

   public List<Integer> getMyInts() {
      return myInts;
   }

   public void setMyInt(List<Integer> something) {
      // myInts = new ArrayList(something);
      myInts = something;
   }

   public String toString() {
      return myInts.toString();
   }

   // Shallow
   /*
   public Deep copy() {
      return new Deep(myInts);
   }
   */

   public Deep copy() {
      return new Deep(new ArrayList<Integer>(myInts));
   }
}
