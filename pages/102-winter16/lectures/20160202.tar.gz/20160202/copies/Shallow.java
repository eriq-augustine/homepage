public class Shallow {
   private int myInt;

   public Shallow(int myInt) {
      this.myInt = myInt;
   }

   public int getMyInt() {
      return myInt;
   }

   public void setMyInt(int something) {
      myInt = something;
   }

   // Cannot return this, need to make a copy.
   /*
   public Shallow copy() {
      return this;
   }
   */

   public Shallow copy() {
      return new Shallow(myInt);
   }
}
