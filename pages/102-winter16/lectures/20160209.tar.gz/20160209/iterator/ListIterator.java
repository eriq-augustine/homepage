import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListIterator {
   public static void main(String[] args) {
      List<String> list = new ArrayList<String>();

      list.add("Dodge");
      list.add("Duck");
      list.add("Dive");
      list.add("Dip");
      list.add("Dodge");

      Iterator<String> iterator = list.iterator();
      while (iterator.hasNext()) {
         String str = iterator.next();
         System.out.print(str + ", ");
      }
      System.out.println();

      for (int i = 0; i < list.size(); i++) {
         System.out.print(list.get(i) + ", ");
      }
      System.out.println();

      // Foreach, For-in
      for (String str : list) {
         System.out.print(str + ", ");
      }
      System.out.println();
   }
}
