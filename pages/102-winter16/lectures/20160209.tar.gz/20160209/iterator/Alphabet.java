import java.util.Iterator;

public class Alphabet implements Iterable<String> {
   public static void main(String[] args) {
      Alphabet abc = new Alphabet();

      Iterator<String> alphaIterator = abc.iterator();
      while (alphaIterator.hasNext()) {
         System.out.print(alphaIterator.next() + " ");
      }
      System.out.println();

      for (String alpha : abc) {
         System.out.print(alpha + " ");
      }
      System.out.println();
   }

   public Iterator<String> iterator() {
      return new AlphaIterator();
   }

   private class AlphaIterator implements Iterator<String> {
      private char current;

      public AlphaIterator() {
         current = 'A';
      }

      public boolean hasNext() {
         return current <= 'Z';
      }

      public String next() {
         if (!hasNext()) {
            throw new java.util.NoSuchElementException();
         }

         String toReturn = "" + current;
         current++;
         return toReturn;
      }

      public void remove() {
         throw new UnsupportedOperationException();
      }
   }
}
