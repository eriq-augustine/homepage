public class LinkedList {
   private Node head;
   private int size;

   public static void main(String[] args) {
      LinkedList list = new LinkedList();
      list.add("One");
      list.add("Two");
      list.add("Three");
      list.add("Four");
      list.add("Five");

      for (int i = 0; i < list.size(); i++) {
         System.out.println(list.get(i));
      }
   }

   public LinkedList() {
      head = null;
      size = 0;
   }

   public void add(Object something) {
      size++;

      if (head == null) {
         head = new Node(something);
         return;
      }

      Node current = head;
      while (current.next != null) {
         current = current.next;
      }

      current.next = new Node(something);
   }

   public Object get(int index) {
      if (index < 0 || index >= size) {
         throw new IndexOutOfBoundsException();
      }

      Node current = head;
      for (int i = 0; i < index; i++) {
         current = current.next;
      }

      return current.data;
   }

   public int size() {
      return size;
   }

   private class Node {
      public Object data;
      public Node next;

      public Node(Object data) {
         this.data = data;
         next = null;
      }
   }
}
