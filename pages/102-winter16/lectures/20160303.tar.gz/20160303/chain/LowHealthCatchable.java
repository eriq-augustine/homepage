public class LowHealthCatchable implements Catchable {
   private Catchable pokemon;

   public LowHealthCatchable(Catchable pokemon) {
      this.pokemon = pokemon;
   }

   public boolean canCatch() {
      if (healthPercent() < .25) {
         return true;
      }

      return pokemon.canCatch();
   }

   public double healthPercent() {
      return pokemon.healthPercent();
   }

   public boolean isParalyzed() {
      return pokemon.isParalyzed();
   }
}
