public class Pokemon implements Catchable {
   private String name;
   private double healthPercent;
   private boolean isParalyzed;

   public Pokemon(String name, double healthPercent) {
      this(name, healthPercent, false);
   }

   public Pokemon(String name, double healthPercent, boolean isParalyzed) {
      this.name = name;
      this.healthPercent = healthPercent;
      this.isParalyzed = isParalyzed;
   }

   public String getName() {
      return name;
   }

   public boolean canCatch() {
      return false;
   }

   public double healthPercent() {
      return healthPercent;
   }

   public boolean isParalyzed() {
      return isParalyzed;
   }
}
