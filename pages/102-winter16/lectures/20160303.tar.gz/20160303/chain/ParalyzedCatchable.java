public class ParalyzedCatchable implements Catchable {
   private Catchable pokemon;

   public ParalyzedCatchable(Catchable pokemon) {
      this.pokemon = pokemon;
   }

   public boolean canCatch() {
      if (isParalyzed()) {
         return true;
      }

      return pokemon.canCatch();
   }

   public double healthPercent() {
      return pokemon.healthPercent();
   }

   public boolean isParalyzed() {
      return pokemon.isParalyzed();
   }
}
