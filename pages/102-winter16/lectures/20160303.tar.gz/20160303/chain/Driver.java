public class Driver {
   public static void main(String[] args) {
      Catchable chansey = new ParalyzedCatchable(new LowHealthCatchable(new Pokemon("Chansey", 1.0)));
      Catchable zubat = new ParalyzedCatchable(new LowHealthCatchable(new Pokemon("Zubat", 0.10)));
      Catchable geodude = new ParalyzedCatchable(new LowHealthCatchable(new Pokemon("Geodude", 1.0, true)));

      System.out.println("Chansey: " + chansey.canCatch());
      System.out.println("Zubat: " + zubat.canCatch());
      System.out.println("Geodude: " + geodude.canCatch());
   }
}
