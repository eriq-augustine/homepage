public interface Catchable {
   public boolean canCatch();
   public double healthPercent();
   public boolean isParalyzed();
}
