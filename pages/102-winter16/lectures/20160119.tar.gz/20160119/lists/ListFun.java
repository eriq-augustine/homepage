import java.util.ArrayList;
import java.util.List;

public class ListFun {
   public static void main(String[] args) {
      List<String> myList = new ArrayList<String>();
      // List<Object> myList = new ArrayList<Object>();
      String[] myArray = new String[10];

      // List myList = new LinkedList();

      myArray[0] = "Hello";
      myArray[1] = "Bye";

      myList.add("Hello");
      myList.add("Bye");

      // Cow myCow = new Cow();
      // myList.add(myCow);
      // myList.add(1);

      for (int i = 0; i < myList.size(); i++) {
         System.out.println("List(" + i + "): " + myList.get(i));
      }

      for (int i = 0; i < myArray.length; i++) {
         System.out.println("Array(" + i + "): " + myArray[i]);
      }

      System.out.println("-------");
      System.out.println(myList);
      System.out.println("-------");
      System.out.println(myArray);
      System.out.println("-------");
   }
}
