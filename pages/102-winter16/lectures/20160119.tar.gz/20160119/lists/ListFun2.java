import java.util.ArrayList;
import java.util.List;

public class ListFun2 {
   public static void main(String[] args) {
      List<Integer> myList = new ArrayList<Integer>();

      myList.add(new Integer(1));
      myList.add(new Integer(2));

      System.out.println(myList.get(0).intValue() + 2);

      for (int i = 0; i < myList.size(); i++) {
         System.out.println("List(" + i + "): " + myList.get(i));
      }

      System.out.println("-------");
      System.out.println(myList);
      System.out.println("-------");
   }
}
