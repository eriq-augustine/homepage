public class Platypus implements Animal {
   public String makeASound() {
      return "Grrrrrrr, I'm a Platypus";
   }

   public String move() {
      return "Swim Swim Scurry";
   }
}
