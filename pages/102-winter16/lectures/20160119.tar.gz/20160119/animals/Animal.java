public interface Animal {
   public String makeASound();
   public String move();
}
