public class Human implements Animal {
   public String makeASound() {
      return "Rabble Rabble";
   }

   public String move() {
      return "Drive Car";
   }

   public String doMath() {
      return "2 + 2 = 4";
   }
}
