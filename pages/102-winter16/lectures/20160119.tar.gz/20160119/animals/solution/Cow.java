public class Cow implements Animal {
   public String makeASound() {
      return "Moooo";
   }

   public String move() {
      return "Slow walk";
   }
}
