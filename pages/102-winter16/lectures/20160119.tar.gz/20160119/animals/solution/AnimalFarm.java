public class AnimalFarm {
   public static void main(String[] args) {
      Animal[] theAnimals = new Animal[3];

      Duck donald = new Duck();
      Cow heffer = new Cow();
      Human eriq = new Human();

      theAnimals[0] = donald;
      theAnimals[1] = heffer;
      theAnimals[2] = eriq;

      for (int i = 0; i < theAnimals.length; i++) {
         System.out.println(theAnimals[i].makeASound());
      }

      // System.out.println(theAnimals[2].doMath());
      System.out.println(eriq.doMath());

      System.out.println(((Human)theAnimals[2]).doMath());
      System.out.println(((Human)theAnimals[0]).doMath());
   }
}
