public class Duck implements Animal {
   public String makeASound() {
      return "Quack";
   }

   public String move() {
      return "Fly (swoosh)";
   }
}
