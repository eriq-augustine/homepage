import java.util.Scanner;

public class AIDriver {
   public static void main(String[] args) {
      HangmanGame game = new HangmanGame();
      HangmanAI ai = new HangmanAI(game.getWord().length());

      System.out.println("Let's Play some hangman!");

      while (!game.done()) {
         System.out.println(game);
         char guess = ai.guess(game.toString());

         try {
            game.guess(guess);
         } catch (Exception ex) {
            System.out.println("God!!>!>!>.... Making me look like an idiot. Play right!!!");
            System.out.println(ex);
         }

         if (game.done()) {
            System.out.println("Game is done!");

            if (game.win()) {
               System.out.println("You WONN!!N!NN!N!N!!!!!");
            } else {
               System.out.println("hahaha, you lost");
               System.out.println("The word was: " + game.getWord());
            }
         }

         System.out.println();
      }

      System.out.println(game);
   }
}
