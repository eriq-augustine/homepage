import java.util.Scanner;

public class HumanPlayer implements HangmanPlayer {
   public char guess(String boardState) {
      System.out.print("Give me a letter and don't mess around!: ");

      Scanner scanner = new Scanner(System.in);
      return scanner.next().charAt(0);
   }
}
