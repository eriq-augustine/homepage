public interface HangmanPlayer {
   public char guess(String boardState);
}
