import java.util.Random;

public class AIPlayer implements HangmanPlayer {
   private int wordLength;
   private Random rand;
   private boolean[] guesses;

   public AIPlayer(int wordLength) {
      this.wordLength = wordLength;
      rand = new Random();
      guesses = new boolean['z' - 'a' + 1];
   }

   public char guess(String boardState) {
      int guessIndex;

      do {
         guessIndex = rand.nextInt(guesses.length);
      } while (guesses[guessIndex]);

      guesses[guessIndex] = true;

      return (char)('a' + guessIndex);
   }
}
