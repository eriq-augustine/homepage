import java.util.Random;

public class HangmanAI implements HangmanPlayer {
   private boolean[] guesses;
   private Random rand;

   public HangmanAI() {
      guesses = new boolean['z' - 'a' + 1];
      rand = new Random();
   }

   public char guess() {
      int guessIndex;

      do {
         guessIndex = rand.nextInt(guesses.length);
      } while(guesses[guessIndex]);

      guesses[guessIndex] = true;

      return (char)('a' + guessIndex);
   }
}
