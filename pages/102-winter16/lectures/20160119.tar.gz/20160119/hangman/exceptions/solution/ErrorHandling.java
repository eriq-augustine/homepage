import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class ErrorHandling {
   public static void main(String[] args) {
      System.out.println(div(1, 2));

      try {
         System.out.println(div(1, 0));
         System.out.println("Try block done");
      } catch (Exception ex) {
         System.out.println("In the catch!");
      }

      // fileStuff();

      System.out.println("Program done");
   }

   public static double div(double a, double b) {
      if (b == 0) {
         throw new RuntimeException("Hey! You can't divide by zero!");
      }

      return a / b;
   }

   public static void fileStuff() throws FileNotFoundException {
      Scanner scanner = new Scanner(new File("asdasd.txt"));
   }
}
