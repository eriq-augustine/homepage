public class MathFun {
   public static void main(String[] args) {
      System.out.println(Math.pow(2, 16));

      System.out.println(Math.PI);

      System.out.println(Math.random());
      System.out.println((int)(Math.random() * 10));

      int num = -1;
      System.out.println(num);
      System.out.println(Math.abs(num));
   }
}
