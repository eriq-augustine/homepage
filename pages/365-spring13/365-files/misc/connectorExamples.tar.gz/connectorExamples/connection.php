<?php

// Connecting, selecting database
$link = mysql_connect('csc-db0.csc.calpoly.edu', 'eaugusti', 'funfun') or die('Could not connect: ' . mysql_error());

mysql_select_db('eaugusti') or die('Could not select database');

// Performing SQL query
$query = 'SELECT * FROM Teachers';
$result = mysql_query($query);

while ($row = mysql_fetch_array($result, MYSQL_ASSOC)) {
   echo $row['last'] . ", " . $row['first'] . " -- " . $row['classroom'] . "\n";
}

// Free resultset
mysql_free_result($result);

// Closing connection
mysql_close($link);
?>
