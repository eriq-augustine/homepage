SELECT COUNT(*) FROM Rooms;

SELECT COUNT(*) FROM Reservations;
