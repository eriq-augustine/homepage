/**
 *  @author Eric Augustine 
 *  Make two vertial bars bordering a bunch of spaces.
 *  One bar on the first column, one bar on the last column.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 11

int
main()
{
   int row, col;

   for (row = 0; row < SIZE; row++)
   {
      for (col = 0; col < SIZE; col++)
      {
         if (col == 0 || col == SIZE - 1)
         {
            printf("|");
         }
         else
         {
            printf(" ");
         }
      }

      printf("\n");
   }

   return EXIT_SUCCESS;
}
