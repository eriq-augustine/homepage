/**
 *  @author Eriq Augustine 
 *  Make a triangle using the bottom two corners and the top left corner
 *  as the points.
 *  Make it look fancy by outlining it.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 11

int
main(int argc, char *argv[])
{
   int row, col;

   for (row = 0; row < SIZE; row++)
   {
      for (col = 0; col <= row; col++)
      {
         if (row == col)
         {
            printf("\\");
         }
         else if (col == 0)
         {
            printf("|");
         }
         else if (row == SIZE - 1)
         {
            printf("_");
         }
         else
         {
            printf("*");
         }
      }

      printf("\n");
   }

   return EXIT_SUCCESS;
}
