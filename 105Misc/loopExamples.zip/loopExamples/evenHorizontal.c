/**
 *  @author Eriq Augustine 
 *  Make horizontal bars.
 *  Odds should be 'x', evens should be '-'
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 11

int
main(int argc, char *argv[])
{
   int row, col;

   for (row = 0; row < SIZE; row++)
   {
      for (col = 0; col < SIZE; col++)
      {
         if (row % 2 == 0)
         {
            printf("-");
         }
         else
         {
            printf("X");
         }
      }

      printf("\n");
   }

   return EXIT_SUCCESS;
}
