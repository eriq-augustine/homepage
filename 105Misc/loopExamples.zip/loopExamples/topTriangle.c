/**
 *  @author Eric Augustine 
 *  Make a trinagle, but use the top two corners and the bottim rigth corner 
 *   as the points.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 11

int
main(int argc, char *argv[])
{
   int row, col;

   for (row = 0; row < SIZE; row++)
   {
      for (col = 0; col < SIZE; col++)
      {
         if (row <= col)
         {
            printf("X");
         }
         else
         {
            printf(" ");
         }
      }

      printf("\n");
   }

   return EXIT_SUCCESS;
}
