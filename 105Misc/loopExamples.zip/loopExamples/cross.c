/**
 *  @author Eriq Augustine 
 *  Plus sign
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 11

int
main(int argc, char *argv[])
{
   int row, col;

   for (row = 0; row < SIZE; row++)
   {
      for (col = 0; col < SIZE; col++)
      {
         if (row == (SIZE / 2) || col == (SIZE / 2))
         {
            printf("+");
         }
         else
         {
            printf(" ");
         }
      }

      printf("\n");
   }

   return EXIT_SUCCESS;
}
