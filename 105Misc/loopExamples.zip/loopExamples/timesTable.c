/**
 *  @author Eric Augustine 
 *  Make a simple times table that goes from 1 to 10.
 *  Make if print nicely and have all the columns line up.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 10

int
main(int argc, char *argv[])
{
   int row, col;

   for (row = 1; row <= SIZE; row++)
   {
      for (col = 1; col <= SIZE; col++)
      {
         printf("%4d ", row * col);
      }

      printf("\n");
   }

   return EXIT_SUCCESS;
}
