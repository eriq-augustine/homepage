/**
 *  @author Eriq Augustine 
 *  Mark the corners with 'X' and the others with '+'
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 11

int
main(int argc, char *argv[])
{
   int row, col;

   for (row = 0; row < SIZE; row++)
   {
      for (col = 0; col < SIZE; col++)
      {
         if ((col == 0 && row == 0) ||
             (col == 0 && row == (SIZE - 1)) ||
             (col == (SIZE - 1) && row == 0) ||
             (col == (SIZE - 1) && row == (SIZE - 1)))
         {
            printf("X");
         }
         else
         {
            printf("+");
         }
      }

      printf("\n");
   }

   return EXIT_SUCCESS;
}
