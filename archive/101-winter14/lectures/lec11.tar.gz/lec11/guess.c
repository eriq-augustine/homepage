/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>
#include <time.h>

int str_length(char str[]) {
   int i = 0;
   while (str[i] != '\0') {
      i++;
   }

   return i;
}

int has_space(char str[]) {
   int i = 0;

   while (str[i] != '\0') {
      if (str[i] == ' ' || str[i] == '\t' || str[i] == '\n') {
         return 1;
      }

      i++;
   }

   return 0;
}

int str_equals(char str1[], char str2[]) {
   int i;

   if (str_length(str1) != str_length(str2)) {
      return 0;
   }

   for (i = 0; i < str_length(str1); i++) {
      if (str1[i] != str2[i]) {
         return 0;
      }
   }

   return 1;
}

int main(int argc, char *argv[]) {
   char* side;
   srand(time(NULL));
   int num = (rand() % 2);

   if (num == 0) {
      side = "heads";
   } else {
      side = "tails";
   }

   if (str_equals(argv[1], side)) {
      printf("Good Job, friend!\n");
   } else {
      printf("You suck, friend!\n");
   }

   printf("Checking \"%s\"\n", argv[2]);
   if (has_space(argv[2])) {
      printf("This has whitespace!\n");
   } else {
      printf("No whitespace :(\n");
   }

   return EXIT_SUCCESS;
}
