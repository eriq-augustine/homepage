/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

int main(int argc, char *argv[])
{
   char str[] = {'a', 'b', 'c', 'd', 'e', '\0'};

   printf("%s\n", str);
   str[2] = '\0';
   printf("%s\n", str);

   return EXIT_SUCCESS;
}
