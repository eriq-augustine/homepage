/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

int str_length(char str[]) {
   int i = 0;
   while (str[i] != '\0') {
      i++;
   }

   return i;
}

int str_equals(char str1[], char str2[]) {
   int i;

   if (str_length(str1) != str_length(str2)) {
      return 0;
   }

   for (i = 0; i < str_length(str1); i++) {
      if (str1[i] != str2[i]) {
         return 0;
      }
   }

   return 1;
}

int main(int argc, char *argv[])
{
   char str[] = "I'm a string";
   printf("%s\n", str);

   char str2[] = "I'm a string";

   // Won't work!
   // if (str == str2) {
   if (str_equals(str, str2)) {
      printf("Yes!\n");
   } else {
      printf("No\n");
   }

   // First arg is the program invocation.
   printf("%d\n", argc);
   printf("%s\n", argv[0]);

   // Print all the args.
   // Will do in lab 07.

   return EXIT_SUCCESS;
}
