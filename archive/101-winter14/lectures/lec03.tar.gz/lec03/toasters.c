/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "checkit.h"
#include "toasters.h"

int main(int argc, char *argv[]) {
   struct toaster some_toaster = create_toaster(20, 1, 'p');

   checkit_int(some_toaster.slots, 20);
   checkit_double(some_toaster.max_temp, 1);
   checkit_char(some_toaster.color, 'p');
   checkit_int(some_toaster.crumb_factor, 10);

   struct bread my_bread = create_bread('s', 10);
   checkit_char(my_bread.type, 's');
   checkit_int(my_bread.size, 10);
   checkit_int(my_bread.is_toasted, 0);

   my_bread = toast(my_bread, some_toaster);

   checkit_int(my_bread.is_toasted, 1);
   checkit_int(my_bread.size, 0);

   print_toaster(some_toaster);

   return 0;
}

struct toaster create_toaster(int slots,
                              double temp,
                              char color) {
   struct toaster silly_toaster;

   silly_toaster.slots = slots;
   silly_toaster.max_temp = temp;
   silly_toaster.color = color;
   silly_toaster.crumb_factor = 10;

   return silly_toaster;
}

struct bread create_bread(char type, int size) {
   struct bread my_bread = {type, size, 0};
   return my_bread;
}

struct bread toast(struct bread to_toast,
                   struct toaster my_toaster) {
   to_toast.is_toasted = 1;
   to_toast.size -= 10;
   // to_toast.size = to_toast.size - 10;
   
   return to_toast;
}

void print_toaster(struct toaster my_toaster) {
      printf("temp: %f, Color: %c, Crumbiness: %d\n",
             my_toaster.max_temp, my_toaster.color);
      /*
      printf("Number of Slots: %d, Max Temp: %f, Color: %c, Crumbiness: %d\n",
             my_toaster.slots, my_toaster.max_temp, my_toaster.color,
             my_toaster.crumb_factor);
      */
}


