struct toaster {
   int slots;
   double max_temp;
   char color;
   // This is in grams.
   int crumb_factor;
};

struct bread {
   char type;
   int size;
   int is_toasted;
};

struct toaster create_toaster(int, double, char);
struct bread create_bread(char type, int size);
struct bread toast(struct bread, struct toaster);
void print_toaster(struct toaster my_toaster);
