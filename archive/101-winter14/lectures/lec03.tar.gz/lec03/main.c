/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

void some_func() {
   printf("I'm in func\n");
}

int main() {
   printf("I'm in main\n");

   some_func();
   return 21;
}
