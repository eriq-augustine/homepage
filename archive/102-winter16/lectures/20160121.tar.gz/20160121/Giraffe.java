public class Giraffe implements Animal {
   private double maneLength;

   public Giraffe() {
      System.out.println("No-Param Constructor");
      this.maneLength = 0;
   }

   // Overloaded Constructor
   public Giraffe(double maneLength) {
      System.out.println("One-Param Constructor");
      this.maneLength = maneLength;
   }

   public String makeASound() {
      return "Hail Satan";
   }

   public String move() {
      return "Stride";
   }

   public String tallTreeEating() {
      return "Nom Nom";
   }

   // Override Object.toString()
   public String toString() {
      return "I'm a giraffe(" + maneLength + "), " + makeASound();
   }

   // Does not override Object.toString(), signature is different.
   // Accidental overload.
   public String toString(int i) {
      return "uh Oh!)";
   }

   public double getManeLength() {
      return maneLength;
   }

   public void grow(double length) {
      System.out.println("Double Grow");
      maneLength += length;
   }

   // Overloaded!
   public void grow(Giraffe spouse) {
      System.out.println("Giraffe Grow");
      maneLength = spouse.maneLength;
   }

   // Overloaded!
   public void grow(Cow spouse) {
      System.out.println("Cow Grow");
      maneLength = spouse.getManeLength();
   }

   // Super dangerous, really ambiguous.
   public void grow(Animal spouse) {
      System.out.println("Animal Grow");
      maneLength = spouse.getManeLength();
   }

   public boolean equals(Object other) {
      // Check nulls.
      if (other == null) {
         return false;
      }

      /* Dangerous with equals()
      if (!(other instanceof Animal)) {
         return false;
      }
      */

      // Check class.
      if (!getClass().equals(other.getClass())) {
         return false;
      }

      Giraffe otherGiraffe = (Giraffe)other;

      // Check privates.
      return maneLength == otherGiraffe.maneLength;
   }
}
