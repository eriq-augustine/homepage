public class Cow implements Animal {
   public String makeASound() {
      return "Mooooooooo";
   }

   public String move() {
      return "Mooooooooove";
   }

   public double getManeLength() {
      return 0;
   }
}
