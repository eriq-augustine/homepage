public class Driver {
   public static void main(String[] args) {
      Giraffe myGiraffe = new Giraffe(4);
      System.out.println(myGiraffe);

      // Same print, java knows myOjb isA Giraffe.
      Object myObj = new Giraffe();
      System.out.println(myObj);

      if (myGiraffe.equals(null)) {
         System.out.println("(Null) Equals");
      } else {
         System.out.println("(Null) Not Equals");
      }

      if (myGiraffe.equals(new Cow())) {
         System.out.println("(Cow) Equals");
      } else {
         System.out.println("(Cow) Not Equals");
      }

      if (myGiraffe.equals(new Giraffe(4))) {
         System.out.println("(Giraffe) Equals");
      } else {
         System.out.println("(Giraffe) Not Equals");
      }

      // Overload

      System.out.println("------- Double --------");

      System.out.println(myGiraffe);
      myGiraffe.grow(7);
      System.out.println(myGiraffe);

      System.out.println("------- Spouse --------");
      System.out.println(myGiraffe);
      myGiraffe.grow(new Giraffe(2));
      System.out.println(myGiraffe);

      System.out.println("------- Cow --------");
      System.out.println(myGiraffe);
      myGiraffe.grow((Animal)(new Cow()));
      System.out.println(myGiraffe);

      /*
      // Won't work, too ambiguious
      System.out.println("------- NULL --------");
      System.out.println(myGiraffe);
      myGiraffe.grow(null);
      System.out.println(myGiraffe);
      */

      /*
      // Won't work, too ambiguious
      System.out.println("------- NULL --------");
      System.out.println(myGiraffe);
      myGiraffe.grow((Object)(new Cow()));
      System.out.println(myGiraffe);
      */
   }
}
