import java.util.ArrayList;
import java.util.List;

// public class MyArrayList extends ArrayList implements List {
public class MyArrayList extends ArrayList {
   public static void main(String[] args) {
      // MyArrayList myList = new MyArrayList();

      // MyArrayList implments List because ArrayList implements List.
      List myList = new MyArrayList();

      myList.add("Giraffe");
      myList.add("Bagel");

      System.out.println(myList);
      System.out.println(myList.get(0));
   }

   public String toString() {
      return "MyArray: " + super.toString();
   }
}
