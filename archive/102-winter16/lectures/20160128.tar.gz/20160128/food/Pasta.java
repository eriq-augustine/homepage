import java.awt.Color;

public class Pasta extends Food {
   private String noodleType;
   private Color noodleColor;

   public Pasta() {
      this("SpookyNoodle", Color.WHITE, 0);
   }

   public Pasta(String noodleType, Color noodleColor, double mass) {
      // Call parent constructor.
      // Pass mass along to the parent.
      super("Pasta (" + noodleType + ")", 2, mass);

      this.noodleType = noodleType;
      this.noodleColor = noodleColor;
   }

   public void pastaTime() {
      // These will not work, mass is private in Food.
      // System.out.println(mass);
      // System.out.println(super.mass);

      // Methods too.
      // System.out.println(calories(10));
      // System.out.println(super.calories(10));
   }
}
