import java.awt.Color;

public class DeliveryPerson {
   public static void main(String[] args) {
      Food spagett = new Pasta("Spagetti", Color.GREEN, 400);
      System.out.println(spagett);
      System.out.println("Calories: " + spagett.getTotalCalories());
      System.out.println("I ate " + spagett.eat(137) + " calories");
      System.out.println("Calories: " + spagett.getTotalCalories());

      System.out.println("----");

      Food cava = new Cavatappi(1);
      System.out.println(cava);
      System.out.println("Calories: " + cava.getTotalCalories());
      System.out.println("I ate " + cava.eat(137) + " calories");
      System.out.println("Calories: " + cava.getTotalCalories());
   }
}
