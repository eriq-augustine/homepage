public class GhostNoodle3 extends Pasta {
   public GhostNoodle3() {
   }
}
