public class Food {
   private String name;
   private int caloriesPerGram;
   private double mass;

   public Food(String name) {
      // Call the other constructor.
      this(name, 0, 0);
   }

   public Food(String name, int caloriesPerGram, double mass) {
      this.name = name;
      this.caloriesPerGram = caloriesPerGram;
      this.mass = mass;
   }

   private double calories(double someMass) {
      return someMass * caloriesPerGram;
   }

   /**
    * Eat some food, remove the mass, and return the calories.
    * @return the number of calories eaten.
    */
   public double eat(double howMuch) {
      if (howMuch < 0) {
         throw new IllegalArgumentException("That's nasty!");
      }

      if (mass < howMuch) {
         howMuch = mass;
      }

      mass -= howMuch;

      return calories(howMuch);
   }

   public double getTotalCalories() {
      return calories(mass);
   }

   public double getMass() {
      return mass;
   }

   public int getCaloriesPerGram() {
      return caloriesPerGram;
   }

   public String getName() {
      return name;
   }
}
