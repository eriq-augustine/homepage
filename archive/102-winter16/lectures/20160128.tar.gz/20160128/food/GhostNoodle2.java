public class GhostNoodle2 extends Pasta {
   public GhostNoodle2() {
      super();
   }
}
