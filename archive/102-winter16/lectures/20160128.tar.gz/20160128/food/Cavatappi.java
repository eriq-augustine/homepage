public class Cavatappi extends Pasta {
   public Cavatappi(double mass) {
      super("Cavatappi", java.awt.Color.YELLOW, mass);
   }
}
