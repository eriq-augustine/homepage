public class GhostNoodle extends Pasta {
}
