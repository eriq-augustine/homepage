import java.util.Arrays;

public class Car implements Comparable<Car> {
   private String make;
   private String model;

   public static void main(String[] args) {
      Car car1 = new Car("Porsche", "911 Carrera");
      Car car2 = new Car("Hyundai", "Accent");
      Car car3 = new Car("Hyundai", "Accent");

      System.out.println(car1.compareTo(car2));
      System.out.println(car2.compareTo(car3));
      System.out.println(car3.compareTo(car1));

      Car[] cars = new Car[]{car1, car2, car3};
      System.out.println(Arrays.toString(cars));
      BubbleSort.sort(cars);
      System.out.println(Arrays.toString(cars));
   }

   public Car(String make, String model) {
      this.make = make;
      this.model = model;
   }

   public int compareTo(Car other) {
      if (!make.equals(other.make)) {
         return make.compareTo(other.make);
      }

      return model.compareTo(other.model);
   }

   public String toString() {
      return make + " " + model;
   }
}
