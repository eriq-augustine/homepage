public class BubbleSort {
   public static void main(String[] args) {
      Integer[] list = new Integer[]{4, -123, 12, 98, 86118, 4, -9871};

      for (Integer num : list) {
         System.out.print("" + num + ", ");
      }
      System.out.println();

      sort(list);

      for (Integer num : list) {
         System.out.print("" + num + ", ");
      }
      System.out.println();
   }

   public static void sort(Comparable[] list) {
      boolean done = false;

      while (!done) {
         done = true;

         for (int i = 0; i < list.length - 1; i++) {
            if (list[i].compareTo(list[i + 1]) > 0) {
               done = false;

               // Swap time
               Comparable temp = list[i];
               list[i] = list[i + 1];
               list[i + 1] = temp;
            }
         }
      }
   }
}
