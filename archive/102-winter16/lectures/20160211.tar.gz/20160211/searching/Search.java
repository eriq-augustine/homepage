public class Search {
   public static final int SIZE = 100000000;
   public static void main(String[] args) {
      int[] list = new int[SIZE];
      for (int i = 0; i < SIZE; i++) {
         list[i] = i;
      }

      long time = System.currentTimeMillis();

      System.out.println(naiveSearch(87, list));
      System.out.println(naiveSearch(-187, list));
      System.out.println(naiveSearch(-187, list));
      System.out.println(naiveSearch(-187, list));
      System.out.println(naiveSearch(-187, list));

      System.out.println("Naive Search: " + (System.currentTimeMillis() - time));
      time = System.currentTimeMillis();

      System.out.println(binarySearch(87, list));
      System.out.println(binarySearch(-187, list));
      System.out.println(binarySearch(-187, list));
      System.out.println(binarySearch(-187, list));
      System.out.println(binarySearch(-187, list));

      System.out.println("Binary Search: " + (System.currentTimeMillis() - time));
      time = System.currentTimeMillis();

      System.out.println(recursiveBinarySearch(87, list));
      System.out.println(recursiveBinarySearch(-187, list));
      System.out.println(recursiveBinarySearch(-187, list));
      System.out.println(recursiveBinarySearch(-187, list));
      System.out.println(recursiveBinarySearch(-187, list));

      System.out.println("Recursive Binary Search: " + (System.currentTimeMillis() - time));
      time = System.currentTimeMillis();
   }

   public static int naiveSearch(int needle, int[] haystack) {
      for (int i = 0; i < haystack.length; i++) {
         if (needle == haystack[i]) {
            return i;
         }
      }

      return -1;
   }

   public static int binarySearch(int needle, int[] haystack) {
      int min = 0;
      int max = haystack.length - 1;

      do {
         int guess = (min + max) / 2;

         if (needle == haystack[guess]) {
            return guess;
         } else if (needle > haystack[guess]) {
            min = guess + 1;
         } else { // needle < haystack[guess]
            max = guess - 1;
         }
      } while(min <= max);

      return -1;
   }

   public static int recursiveBinarySearch(int needle, int[] haystack) {
      return recursiveBinarySearch(needle, haystack, 0, haystack.length - 1);
   }

   private static int recursiveBinarySearch(int needle, int[] haystack, int min, int max) {
      if (min > max) {
         return -1;
      }

      int guess = (min + max) / 2;

      if (needle == haystack[guess]) {
         return guess;
      } else if (needle > haystack[guess]) {
         return recursiveBinarySearch(needle, haystack, guess + 1, max);
      } else { // needle < haystack[guess]
         return recursiveBinarySearch(needle, haystack, min, guess - 1);
      }
   }
}
