import java.io.File;
import java.util.Scanner;

public class ErrorHandling {
   public static void main(String[] args) {
      System.out.println(div(1, 2)); // Works

      try {
         System.out.println(div(1, 0));
         System.out.println("Try is done");
      } catch (Exception ex) {
         System.out.println("Catcher in the Rye: " + ex);
      }

      System.out.println("Program is done");
   }

   public static double div(double a, double b) {
      if (b == 0) {
         throw new RuntimeException("Hey! You can't divide by zero!");
      }

      return a / b;
   }

   public static void fileStuff() throws java.io.FileNotFoundException {
      Scanner scanner = new Scanner(new File("asdasdkja.aiuag"));
   }
}
