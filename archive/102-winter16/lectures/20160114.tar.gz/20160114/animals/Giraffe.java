public class Giraffe implements Animal {
   public String makeASound() {
      return "Hail Satan";
   }

   public String move() {
      return "Stride";
   }

   public String tallTreeEating() {
      return "Nom Nom";
   }
}
