public class AnimalFarm {
   public static void main(String[] args) {
      Animal[] pen = new Animal[3];

      Cow myCow = new Cow();
      Animal someCow = myCow;

      pen[0] = new Cow();
      pen[1] = new Giraffe();
      pen[2] = new Platypus();

      for (int i = 0; i < pen.length; i++) {
         System.out.println(pen[i].makeASound());
      }

      // System.out.println(pen[1].tallTreeEating()); // Won't work
      System.out.println(((Giraffe)(pen[1])).tallTreeEating());

      // Won't work, pen[0] is a cow, not a giraffe.
      // System.out.println(((Giraffe)(pen[0])).tallTreeEating());
   }
}
