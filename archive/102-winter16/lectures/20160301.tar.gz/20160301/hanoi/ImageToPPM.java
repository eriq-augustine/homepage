import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.Point;
import java.io.File;
import javax.imageio.ImageIO;

public class ImageToPPM {
   public static void main(String[] args) throws Exception {
      if (args.length != 1) {
         System.err.println("USAGE: java ImageToCanvas <file.png>");
         System.exit(1);
      }

      BufferedImage image = ImageIO.read(new File(args[0]));

      int width = image.getWidth();
      int height = image.getHeight();

      Canvas canvas = new Canvas();

      for (int row = 0; row < height; row++) {
         for (int col = 0; col < width; col++) {
            int color = image.getRGB(col, row);

            canvas.add(new Rectangle(1, 1, new Point(col, row), new Color(color), true));
         }
      }

      Draw.draw(canvas, width, height, Color.WHITE, args[0].replaceFirst("\\..+$", ".ppm"));
   }
}
