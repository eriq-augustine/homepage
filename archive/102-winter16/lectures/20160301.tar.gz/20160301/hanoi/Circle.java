/**
 * Circle class.
 *
 * @author Kurt Mammen
 * @version Project 4
 * @version CPE102-X
 * @version Winter 20XX
 */

import java.awt.Color;
import java.awt.Point;

public class Circle implements Shape
{
   private Color color;
   private boolean filled;

   private double r;
   private Point position;

   /** Constructor.
    * @param radius The radius of the circle.
    * @param color The java.awt.Color of the circle.
    * @param position The position of the circle.
    */
   public Circle(double radius, Point position, Color color, boolean filled)
   {
      r = radius;
      this.position = position;
      this.color = color;
      this.filled = filled;
   }

   /** Returns the radius of the circle.
    * @return The radius of the circle.
    */
   public double getRadius()
   {
      return r;
   }

   /** Changes the redius of the circle.
    * @param radius The new radius of the circle.
    */
   public void setRadius(double radius)
   {
      r = radius;
   }

   public boolean equals(Object other)
   {
      if (other == null)
      {
         return false;
      }

      if (getClass() != other.getClass())
      {
         return false;
      }

      if (!color.equals(((Circle)other).color))
      {
         return false;
      }

      if (filled != ((Circle)other).filled)
      {
         return false;
      }

      if (!position.equals(((Circle)other).position))
      {
         return false;
      }

      if (r != ((Circle)other).r)
      {
         return false;
      }

      return true;
   }

   // Shape interface stuff...
   //
   public double getArea()
   {
      return Math.PI * r * r;
   }

   public Color getColor()
   {
      return color;
   }

   public void setColor(Color color)
   {
      this.color = color;
   }

   public boolean getFilled()
   {
      return filled;
   }

   public void setFilled(boolean filled)
   {
      this.filled = filled;
   }

   public void move(Point delta)
   {
      position.x += delta.x;
      position.y += delta.y;
   }

   public Point getPosition()
   {
      return position;
   }

   public void setPosition(Point position)
   {
      this.position = position;
   }
}
