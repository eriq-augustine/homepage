import java.util.ArrayList;
import java.awt.Color;

public class Canvas
{
   private ArrayList<Shape> canvas = new ArrayList<Shape>();

   public void add(Shape shape)
   {
      canvas.add(shape);
   }

   public Shape remove(int index)
   {
      if (index < 0 || index >= canvas.size())
      {
         return null;
      }

      return canvas.remove(index);
   }

   public Shape get(int index)
   {
      if (index < 0 || index >= canvas.size())
      {
         return null;
      }

      return canvas.get(index);
   }

   public int size()
   {
      return canvas.size();
   }

   //public ArrayList<Shape> getCircles()
   public ArrayList<Circle> getCircles()
   {
      //ArrayList<Shape> circles = new ArrayList<Shape>();
      ArrayList<Circle> circles = new ArrayList<Circle>();

      for(int i = 0; i < canvas.size(); i++)
      {
         if (canvas.get(i) instanceof Circle)
         {
            circles.add((Circle)canvas.get(i));
         }
      }

      return circles;
   }

   //public ArrayList<Shape> getRectangles()
   public ArrayList<Rectangle> getRectangles()
   {
      //ArrayList<Shape> rects = new ArrayList<Shape>();
      ArrayList<Rectangle> rects = new ArrayList<Rectangle>();

      for(int i = 0; i < canvas.size(); i++)
      {
         if (canvas.get(i) instanceof Rectangle)
         {
            rects.add((Rectangle)canvas.get(i));
         }
      }

      return rects;
   }

   //public ArrayList<Shape> getTriangles()
   public ArrayList<Triangle> getTriangles()
   {
      //ArrayList<Shape> tris = new ArrayList<Shape>();
      ArrayList<Triangle> tris = new ArrayList<Triangle>();

      for(int i = 0; i < canvas.size(); i++)
      {
         if (canvas.get(i) instanceof Triangle)
         {
            tris.add((Triangle)canvas.get(i));
         }
      }

      return tris;
   }

   //public ArrayList<Shape> getConvexPolygons()
   public ArrayList<ConvexPolygon> getConvexPolygons()
   {
      //ArrayList<Shape> polys = new ArrayList<Shape>();
      ArrayList<ConvexPolygon> polys = new ArrayList<ConvexPolygon>();

      for(int i = 0; i < canvas.size(); i++)
      {
         if (canvas.get(i) instanceof ConvexPolygon)
         {
            polys.add((ConvexPolygon)canvas.get(i));
         }
      }

      return polys;
   }

   public ArrayList<Shape> getShapesByColor(Color color)
   {
      ArrayList<Shape> list = new ArrayList<Shape>();

      for(Shape s : canvas)
      {
         if (s.getColor().equals(color))
         {
            list.add(s);
         }
      }

      return list;
   }

   public double getAreaOfAllShapes()
   {
      double area = 0;

      for (Shape s : canvas)
      {
         area += s.getArea();
      }

      return area;
   }
}
