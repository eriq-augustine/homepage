/**
 * Shape interface specifying general operations an any geometric shape.
 *
 * @author Kurt Mammen
 * @version Project 2
 * @version CPE102-X
 * @version Spring 2006
 */

 import java.awt.Color;
 import java.awt.Point;

 public interface Shape
 {
   /** Calculates and returns the area of the shape.
    * @return Returns the area of the shape.
    */
   public double getArea();

   /** Returns the java.awt.Color of the shape.
    * @return Returns the color of the shape.
    */
   Color getColor();

   /** Sets the java.awt.Color of the shape.
    * @param color The color to fill the shape with.
    */
   void setColor(Color color);

   /** Returns filled-state of the shape.
    * @return Returns true if the shape is filled, otherwise false.
    */
   boolean getFilled();

   /** Sets the filled-tate of the shape.
    * @param filled Specifies if the shape is color filled (solid) on not.
    */
   void setFilled(boolean filled);

   /** Moves the shape by the x and y amounts specified in the Point.
    * @param delta Specifies the x and y amounts to move the shape.
    */
   void move(Point delta);

   /** Returns the current position of the shape in the drawing space.
    * @return The current position of the shape in the drawing space.
    */
   Point getPosition();

   /** Sets the position of the shape in the drawing space.
    * @param position The new position of the shape.
    */
   void setPosition(Point position);
 }
