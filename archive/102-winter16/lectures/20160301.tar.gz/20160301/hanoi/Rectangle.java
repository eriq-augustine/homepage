/**
 * Rectangle class.
 *
 * @author Kurt Mammen
 * @version Project 4
 * @version CPE102-X
 * @version Winter 20XX
 */
 
import java.awt.Color;
import java.awt.Point;

public class Rectangle implements Shape
{
   private Color color;
   private boolean filled;
   
   private int w, h;
   private Point position;
   
   public Rectangle(int width,
                    int height,
                    Point position,
                    Color color,
                    boolean filled)
   {
      w = width;
      h = height;
      this.position = position;
      this.color = color;
      this.filled = filled;
   }
   
   public int getWidth()
   {
      return w;
   }
   
   public void setWidth(int width)
   {
      w = width;
   }

   public int getHeight()
   {
      return h;
   }
   
   public void setHeight(int height)
   {
      h = height;
   }

   public boolean equals(Object other)
   {
      if (other == null)
      {
         return false;
      }
      
      if (getClass() != other.getClass())
      {
         return false;
      }
      
      if (!color.equals(((Rectangle)other).color))
      {
         return false;
      }
      
      if (filled != ((Rectangle)other).filled)
      {
         return false;
      }
      
      if (!position.equals(((Rectangle)other).position))
      {
         return false;
      }
      
      if (w != ((Rectangle)other).w)
      {
         return false;
      }
  
      if (h != ((Rectangle)other).h)
      {
         return false;
      }
       
      return true;
   }

   // Shape interface stuff...
   //
   public double getArea()
   {
      return w * h;
   }

   public Color getColor()
   {
      return color;
   }

   public void setColor(Color color)
   {
      this.color = color;
   }

   public boolean getFilled()
   {
      return filled;
   }
   
   public void setFilled(boolean filled)
   {
      this.filled = filled;
   }

   public void move(Point delta)
   {
      position.x += delta.x;
      position.y += delta.y;     
   } 
   
   public Point getPosition()
   {
      return position;
   }
  
   public void setPosition(Point position)
   {
      this.position = position;
   } 
}
