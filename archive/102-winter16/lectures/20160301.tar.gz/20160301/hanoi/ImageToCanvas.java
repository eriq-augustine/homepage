import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.Point;
import java.io.File;
import java.io.PrintStream;
import javax.imageio.ImageIO;

public class ImageToCanvas {
   private static final String CANVAS_FILE = "MyCanvas.java";

   public static void main(String[] args) throws Exception {
      if (args.length != 1) {
         System.err.println("USAGE: java ImageToCanvas <file.png>");
         System.exit(1);
      }

      BufferedImage image = ImageIO.read(new File(args[0]));
      String newName = args[0].replaceFirst("\\..+$", ".ppm");

      write(image, newName, new PrintStream(new File(CANVAS_FILE)));
   }

   public static void write(BufferedImage image, String imageName, PrintStream out) throws Exception {
      int width = image.getWidth();
      int height = image.getHeight();

      out.println("import java.awt.Color;");
      out.println("import java.awt.Point;");
      out.println();
      out.println("public class MyCanvas {");
      out.println("   public static void main(String[] args) {");
      out.println("      Canvas canvas = createCanvas();");
      out.printf( "      Draw.draw(canvas, %d, %d, Color.WHITE, \"%s\");\n", width, height, imageName);
      out.println("   }");

      // We need to split each row into a different method because java can only have 65k per method.
      out.println();
      out.println("   public static Canvas createCanvas() {");
      out.println("      Canvas canvas = new Canvas();");
      out.println();

      for (int row = 0; row < height; row++) {
         out.printf("      addRow%d(canvas);\n", row);
      }

      out.println();
      out.println("      return canvas;");
      out.println("   }");

      for (int row = 0; row < height; row++) {

         out.println();
         out.printf("   public static void addRow%d(Canvas canvas) {\n", row);
         out.printf("      String colors = \"");

         for (int col = 0; col < width; col++) {
            int color = image.getRGB(col, row);
            out.printf("%d%s", color, (col == width - 1) ? "\";\n" : ",");
         }

         out.println();
         out.println("      String[] colorArray = colors.split(\",\");");
         out.println("      for (int i = 0; i < colorArray.length; i++) {");
         out.printf( "         canvas.add(new Rectangle(1, 1, new Point(i, %d), new Color(Integer.parseInt(colorArray[i])), true));\n", row);
         out.println("      }");
         out.println("   }");
      }

      out.println("}");
   }
}
