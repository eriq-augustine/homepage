/**
 * Triangle class.
 *
 * @author Kurt Mammen
 * @version Project 4
 * @version CPE102-X
 * @version Winter 20XX
 */

import java.awt.Color;
import java.awt.Point;

public class Triangle implements Shape
{
   private Point a, b, c;
   private Color color;
   private boolean filled;

   public Triangle(Point a, Point b, Point c, Color color, boolean filled)
   {
      this.a = a;
      this.b = b;
      this.c = c;
      this.color = color;
      this.filled = filled;
   }

   public Point getVertexA()
   {
      return a;
   }

   public void setVertexA(Point vertex)
   {
      a = vertex;
   }

   public Point getVertexB()
   {
      return b;
   }

   public void setVertexB(Point vertex)
   {
      b = vertex;
   }

   public Point getVertexC()
   {
      return c;
   }

   public void setVertexC(Point vertex)
   {
      c = vertex;
   }

   public boolean equals(Object other)
   {
      if (other == null)
      {
         return false;
      }

      if (getClass() != other.getClass())
      {
         return false;
      }

      if (!a.equals(((Triangle)other).a))
      {
         return false;
      }

      if (!b.equals(((Triangle)other).b))
      {
         return false;
      }

      if (!c.equals(((Triangle)other).c))
      {
         return false;
      }

      if (!color.equals(((Triangle)other).color))
      {
         return false;
      }

      if (filled != ((Triangle)other).filled)
      {
         return false;
      }

      return true;
   }

   // Shape interface stuff...
   //
   public double getArea()
   {
     // Calculate the semiperimeter
     double da = a.distance(b);
     double db = b.distance(c);
     double dc = c.distance(a);

     double sp = (da + db + dc) / 2;

     return Math.sqrt(sp * (sp - da) * (sp - db) * (sp - dc));
   }

   public Color getColor()
   {
      return color;
   }

   public void setColor(Color color)
   {
      this.color = color;
   }

   public boolean getFilled()
   {
      return filled;
   }

   public void setFilled(boolean filled)
   {
      this.filled = filled;
   }

   public void move(Point delta)
   {
      a.x += delta.x;
      a.y += delta.y;

      b.x += delta.x;
      b.y += delta.y;

      c.x += delta.x;
      c.y += delta.y;
   }

   public void setPosition(Point position)
   {
      int dx = position.x - a.x;
      int dy = position.y - a.y;

      a = position;
      b.translate(dx, dy);
      c.translate(dx, dy);
   }

   public Point getPosition()
   {
      return a;
   }
}
