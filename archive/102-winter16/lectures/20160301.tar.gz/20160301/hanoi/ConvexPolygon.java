/**
 * ConvexPolygon class.
 *
 * @author Kurt Mammen
 * @version Project 2
 * @version CPE102-X
 * @version Spring 2006
 */

import java.awt.Color;
import java.awt.Point;
import java.util.Arrays;

public class ConvexPolygon implements Shape
{
   private Point[] vertices;
   private Color color;
   private boolean filled;

   public ConvexPolygon(Point[] vertices, Color color, boolean filled)
   {
      this.vertices = vertices;
      this.color = color;
      this.filled = filled;
   }

   public Point getVertex(int index)
   {
      return vertices[index];
   }

   public void setVertex(int index, Point vertex)
   {
      vertices[index] = vertex;
   }

   public boolean equals(Object other)
   {
      if (other == null)
      {
         return false;
      }

      if (getClass() != other.getClass())
      {
         return false;
      }

      if (!color.equals(((ConvexPolygon)other).color))
      {
         return false;
      }

      if (filled != ((ConvexPolygon)other).filled)
      {
         return false;
      }

      // Not how most students would do it...
      // return Arrays.deepEquals(vertices, ((ConvexPolygon)other).vertices);

      if (vertices.length != ((ConvexPolygon)other).vertices.length)
      {
         return false;
      }

      for (int i = 0; i < vertices.length; i++)
      {
         if (!vertices[i].equals(((ConvexPolygon)other).vertices[i]))
         {
            return false;
         }
      }

      return true;
   }

   // Shape interface stuff...
   //
   public double getArea()
   {
      int a = 0;
      int b = 0;
      int[] x = new int[vertices.length + 1];
      int[] y = new int[vertices.length + 1];

      // Init array to calc determinates...
      for (int i = 0; i < vertices.length; i++)
      {
         x[i] = vertices[i].x;
         y[i] = vertices[i].y;
      }

      // Initialize last point (start-end point)...
      x[vertices.length] = vertices[0].x;
      y[vertices.length] = vertices[0].y;

      // Calc determinates...
      for(int i = 0; i < vertices.length; i++)
      {
         a += x[i] * y[i + 1];
         b += y[i] * x[i + 1];
      }

      return (a - b) / 2;
   }

   public Color getColor()
   {
      return color;
   }

   public void setColor(Color color)
   {
      this.color = color;
   }

   public boolean getFilled()
   {
      return filled;
   }

   public void setFilled(boolean filled)
   {
      this.filled = filled;
   }

   public void move(Point delta)
   {
      for (int i = 0; i < vertices.length; i++)
      {
         vertices[i].x += delta.x;
         vertices[i].y += delta.y;
      }
   }

   public void setPosition(Point position)
   {
      int dx = position.x - vertices[0].x;
      int dy = position.y - vertices[0].y;

      vertices[0] = position;

      for (int i = 1; i < vertices.length; i++)
      {
         vertices[i].translate(dx, dy);
      }
   }

   public Point getPosition()
   {
      return vertices[0];
   }

   public int numVertices() {
      return vertices.length;
   }
}
