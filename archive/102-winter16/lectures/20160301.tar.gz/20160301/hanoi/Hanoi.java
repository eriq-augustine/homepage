import java.awt.Color;
import java.awt.Point;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class Hanoi {
   private int numDisks;
   private List<State> steps;
   private Peg[] pegs;

   private Color[] diskColors;

   public static void main(String[] args) {
      if (args.length != 1) {
         System.out.println("USAGE: java Hanoi <num disks>");
         System.exit(1);
      }

      Hanoi game = new Hanoi(Integer.parseInt(args[0]));
      System.out.println(game);

      String prefix = "out/hanoi_";
      for (int i = 0; i < game.size(); i++) {
         game.getStep(i).draw(String.format("%s%03d.ppm", prefix, i));
      }
   }

   public Hanoi(int numDisks) {
      this.numDisks = numDisks;
      steps = new ArrayList<State>();
      pegs = new Peg[]{new Peg(), new Peg(), new Peg()};

      // Add all the starting disks.
      for (int i = numDisks; i > 0; i--) {
         pegs[0].push(i);
      }

      diskColors = new Color[numDisks];
      for (int i = 0; i < numDisks; i++) {
         diskColors[i] = ColorUtils.nextColor();
      }

      saveState();
      solve(numDisks, pegs[0], pegs[1], pegs[2]);
   }

   public String toString() {
      String rtn = "";

      for (int i = 0; i < steps.size(); i++) {
         rtn += steps.get(i).toString();

         if (i != steps.size() - 1) {
            rtn += "\n";
         }
      }

      return rtn;
   }

   public State getStep(int i) {
      return steps.get(i);
   }

   public int size() {
      return steps.size();
   }

   private void solve(int numToMove, Peg start, Peg extra, Peg end) {
      if (numToMove == 1) {
         end.push(start.pop());
         saveState();
         return;
      }

      solve(numToMove - 1, start, end, extra);

      end.push(start.pop());
      saveState();

      solve(numToMove - 1, extra, start, end);
   }

   private void saveState() {
      steps.add(new State(pegs));
   }

   private static class Peg extends LinkedList<Integer> {
      public Peg() {
         super();
      }

      public Peg(LinkedList<Integer> peg) {
         super(peg);
      }
   }

   private class State {
      public static final int DISK_HEIGHT = 50;
      public static final int BASE_DISK_RADIUS = 60;
      public static final int PEG_WIDTH = 30;
      public static final int CANVAS_PADDING = 100;
      public static final int INTER_DISK_SPACE = 50;

      // These would be static, but java doesn't know Color is immutable.
      public final Color BG_COLOR = Color.WHITE;
      public final Color PEG_COLOR = new Color(102, 51, 0);

      public Peg[] pegs;

      int pegHeight;
      int maxDiskRadius;
      int maxDiskToPeg;
      int canvasWidth;
      int canvasHeight;

      public State(Peg[] pegs) {
         this.pegs = new Peg[pegs.length];
         for (int i = 0; i < pegs.length; i++) {
            this.pegs[i] = new Peg(pegs[i]);
         }

         pegHeight = (numDisks + 1) * DISK_HEIGHT;
         maxDiskRadius = BASE_DISK_RADIUS * numDisks;
         maxDiskToPeg = maxDiskRadius - (PEG_WIDTH / 2);
         canvasWidth = (2 * CANVAS_PADDING) + ((pegs.length - 1) * INTER_DISK_SPACE) + (pegs.length * 2 * maxDiskRadius);
         canvasHeight = pegHeight + (2 * CANVAS_PADDING);
      }

      public String toString() {
         String rtn = "";

         for (int i = 0; i < pegs.length; i++) {
            rtn += String.format("%2d", pegs[i].size());

            if (i != pegs.length - 1) {
               rtn += " ";
            }
         }

         return rtn;
      }

      public Canvas toCanvas() {
         Canvas canvas = new Canvas();

         // TODO(eriq): Don't hardcode the number of pegs.

         // Peg 1
         canvas.add(new Rectangle(PEG_WIDTH, pegHeight,
                                  new Point(
                                       CANVAS_PADDING + (0 * ((2 * maxDiskRadius) + INTER_DISK_SPACE)) + maxDiskToPeg,
                                       canvasHeight - CANVAS_PADDING),
                                  PEG_COLOR, true));

         // Peg 2
         canvas.add(new Rectangle(PEG_WIDTH, pegHeight,
                                  new Point(
                                       CANVAS_PADDING + (1 * ((2 * maxDiskRadius) + INTER_DISK_SPACE)) + maxDiskToPeg,
                                       canvasHeight - CANVAS_PADDING),
                                  PEG_COLOR, true));

         // Peg 3
         canvas.add(new Rectangle(PEG_WIDTH, pegHeight,
                                  new Point(
                                       CANVAS_PADDING + (2 * ((2 * maxDiskRadius) + INTER_DISK_SPACE)) + maxDiskToPeg,
                                       canvasHeight - CANVAS_PADDING),
                                  PEG_COLOR, true));

         for (int pegIndex = 0; pegIndex < pegs.length; pegIndex++) {
            int pegEdge = CANVAS_PADDING + (pegIndex * ((2 * maxDiskRadius) + INTER_DISK_SPACE)) + maxDiskToPeg;
            int pegCenter = pegEdge + (PEG_WIDTH / 2);

            // We are going through a stack, so our indexes are a little off.
            int diskIndexFromBottom = pegs[pegIndex].size() - 1;
            for (Integer disk : pegs[pegIndex]) {
               int diskBase = canvasHeight - CANVAS_PADDING - (diskIndexFromBottom * DISK_HEIGHT);
               int diskRadius = disk.intValue() * BASE_DISK_RADIUS;

               canvas.add(new Rectangle(diskRadius * 2, DISK_HEIGHT,
                                        new Point(pegCenter - diskRadius, diskBase),
                                        diskColors[disk.intValue() - 1], true));

               diskIndexFromBottom--;
            }
         }

         return canvas;
      }

      public void draw(String filename) {
         Canvas canvas = toCanvas();
         Draw.draw(canvas, canvasWidth, canvasHeight, BG_COLOR, filename);
      }
   }
}
