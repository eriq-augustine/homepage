public class LinkedList<E> {
   private Node head;
   private int size;

   public static void main(String[] args) {
      LinkedList<String> list = new LinkedList<String>();
      list.add("One");
      list.add("Two");
      list.add("Three");
      list.add("Four");
      list.add("Five");

      for (int i = 0; i < list.size(); i++) {
         System.out.println(list.get(i));
      }
   }

   public LinkedList() {
      head = null;
      size = 0;
   }

   public void add(E something) {
      head = add(head, something);
      size++;
   }

   private Node add(Node list, E something) {
      if (list == null) {
         return new Node(something);
      }

      list.next = add(list.next, something);
      return list;
   }

   // Public access (started) method.
   public E get(int index) {
      if (index < 0 || index >= size) {
         throw new IndexOutOfBoundsException();
      }

      return get(index, head);
   }

   // Recursive helper method.
   private E get(int index, Node current) {
      if (index == 0) {
         return current.data;
      }

      return get(index - 1, current.next);
   }

   public int size() {
      return size;
   }

   // Don't do this!
   // private class Node<E> {
   private class Node {
      public E data;
      public Node next;

      public Node(E data) {
         this.data = data;
         next = null;
      }
   }
}
