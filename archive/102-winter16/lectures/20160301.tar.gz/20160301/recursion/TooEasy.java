public class TooEasy {
   public static void main(String[] args) {
      System.out.println(summation(3));
      System.out.println(summation(5));
      System.out.println(summation(500));
   }

   public static int summation(int num) {
      // Base case
      if (num == 1) {
         return 1;
      }

      // Recursive case
      return num + summation(num - 1);
   }
}
