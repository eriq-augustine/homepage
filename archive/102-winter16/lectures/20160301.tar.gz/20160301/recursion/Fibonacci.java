public class Fibonacci {
   public static void main(String[] args) {
      System.out.println(fib(3));
      System.out.println(fib(5));
      System.out.println(fib(500));
   }

   public static int fib(int num) {
      // Base case
      if (num <= 1) {
         return 1;
      }

      // Recursive case
      return fib(num - 1) + fib(num - 2);
   }
}
