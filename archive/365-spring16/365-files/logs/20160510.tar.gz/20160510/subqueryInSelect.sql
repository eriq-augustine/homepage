-- Setup so the next query shows something.
-- Make sure to rebuild your database before working on labs!
INSERT INTO Customers
   (cId, firstName, lastName)
SELECT
   1000 + classroom * (LENGTH(lastName) + LENGTH(firstName) * 10),
   firstName,
   lastName
FROM List
WHERE
   grade = 4
   AND firstName <> 'ELTON'
;

-- Use a subquery inside of the SELECT clause.
-- Make sure it returns a single value.
SELECT
   firstName,
   lastName,
   (SELECT COUNT(*) FROM List WHERE firstName = C.firstName) AS numStudents
FROM Customers C
;
