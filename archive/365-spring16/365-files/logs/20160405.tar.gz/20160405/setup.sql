DROP TABLE IF EXISTS Characters;
DROP TABLE IF EXISTS MoveSets;

CREATE TABLE MoveSets (
   id INT,
   button VARCHAR(16),
   action TEXT,
   UNIQUE(id, button)
);

CREATE TABLE Characters (
   name VARCHAR(32),
   weight FLOAT NOT NULL,
   fallSpeed INTEGER NULL,
   moveSet INT REFERENCES MoveSets(id),
   image BLOB,
   CONSTRAINT Necessary PRIMARY KEY (name)
);

INSERT INTO MoveSets
   (id, button, action)
VALUES
   (1, 'A', 'Jab'),
   (1, 'B', 'Lazer')
;

INSERT INTO MoveSets
   (id, button, action)
VALUES
   (2, 'B', 'Warlock Punch')
;

INSERT INTO Characters
   (name, weight, fallSpeed, moveSet)
VALUES
   ('Fox', 4.5, 17, 1),
   ('Ganondorf', 4.0, 11, 2)
;
