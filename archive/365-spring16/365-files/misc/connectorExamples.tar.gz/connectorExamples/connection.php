<?php

// Connecting, selecting database
# $link = mysqli_connect('csc-db0.csc.calpoly.edu', 'eaugusti', 'funfun', 'eaugusti') or die('Could not connect: ' . mysqli_error());
$link = mysqli_connect('localhost', '', '') or die('Could not connect: ' . mysqli_error());

mysqli_select_db($link, 'eaugusti') or die('Could not select database');

// Performing SQL query
$query = 'SELECT * FROM Teachers';
$result = mysqli_query($link, $query);

while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
   echo $row['last'] . ", " . $row['first'] . " -- " . $row['classroom'] . "\n";
}

// Free resultset
mysqli_free_result($result);

// Closing connection
mysqli_close($link);
?>
