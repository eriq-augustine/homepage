import MySQLdb

# db = MySQLdb.connect(host = "csc-db0.csc.calpoly.edu",
#                      user = "eaugusti",
#                      passwd = "funfun",
#                      db = "eaugusti")

db = MySQLdb.connect(host = "localhost",
                     user = "",
                     passwd = "",
                     db = "eaugusti",
                     unix_socket = "/media/media/mysql/mysql.sock")

# you must create a Cursor object. It will let
#  you execute all the query you need
cur = db.cursor()

# Use all the SQL you like
cur.execute("SELECT * FROM Teachers")

for row in cur.fetchall():
   print row[0] + ", " + row[1] + " -- " + str(row[2])
