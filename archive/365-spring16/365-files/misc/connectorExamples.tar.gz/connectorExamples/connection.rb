require 'mysql'

# db = Mysql::new("csc-db0.csc.calpoly.edu", "eaugusti", "funfun", "eaugusti")
db = Mysql::new("localhost", "", "", "eaugusti", 3306, '/media/media/mysql/mysql.sock')

res = db.query("SELECT * FROM Teachers")
res.each{|row|
   puts "#{row[0]}, #{row[1]} -- #{row[2]}"
}

db.close()
