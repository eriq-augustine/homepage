SELECT COUNT(*) FROM Campuses;

SELECT COUNT(*) FROM Fees;

SELECT COUNT(*) FROM Degrees;

SELECT COUNT(*) FROM Disciplines;

SELECT COUNT(*) FROM DisciplineEnrollments;

SELECT COUNT(*) FROM Enrollments;

SELECT COUNT(*) FROM Faculty;
