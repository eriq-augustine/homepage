/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 5

// Looking for the null, might not find it.
void garbage() {
   char str[SIZE * 80];
   printf("[%s]\n", str);
}

void for_str() {
   char str[SIZE];
   int i;

   for (i = 0; i < SIZE - 1; i++) {
      str[i] = 'a' + i;
   }
   str[SIZE - 1] = '\0';

   printf("%s\n", str);
}

void implicit() {
   char str[] = "Hello, there!";
   printf("%s\n", str);
}

void arr_str() {
   char str[] = {'a', 'b', 'c', 'd', '\0'};
   printf("%s --> %c\n", str, str[2]);
   str[2] = 'C';
   printf("%s --> %c\n", str, str[2]);

   char str2[] = "Hi, Friend";
   str2[5] = '4';
   printf("%s\n", str2);
}

int main(int argc, char *argv[])
{
   garbage();
   for_str();
   implicit();
   arr_str();

   return EXIT_SUCCESS;
}
