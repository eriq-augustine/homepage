/**
 *  @author Eric Augustine
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

int str_length(char str[]) {
   int i = 0;
   while (str[i] != '\0') {
      i++;
   }

   return i;
}

void print_str_for(char str[]) {
   int i = 0;
   for (i = 0; i < str_length(str); i++) {
      printf("%c", str[i]);
   }
   printf("\n");
}

void caps_plz(char str[]) {
   int i = 0;
   // Null char is ascii 0, which is false in c.
   while (str[i]) {
      if ('a' <= str[i] && 'z' >= str[i]) {
         str[i] -= ('a' - 'A');
      }
      i++;
   }
}

void print_str(char str[]) {
   int i = 0;
   while (str[i] != '\0') {
      printf("%c", str[i]);
      i++;
   }
   printf("\n");
}

int main(int argc, char *argv[])
{
   print_str("Cool, dogs.");

   char str[] = "Cool, dogs.";
   caps_plz(str);
   printf("%s\n", str);

   char one_more[700];
   one_more[0] = '\0';

   printf("%d\n", str_length(str));
   printf("%d\n", str_length("Some other string"));
   printf("%d\n", str_length(one_more));

   print_str_for("Cool, dogs.");

   return EXIT_SUCCESS;
}
