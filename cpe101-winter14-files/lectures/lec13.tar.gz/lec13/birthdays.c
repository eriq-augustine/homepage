#include <stdio.h>

struct Person {
   char name[20];
   int birth_month;
   int birth_day;
} ;

int find_min_bday(struct Person people[], int size) {
   int min_month = people[0].birth_month;
   int min_day = people[0].birth_day;
   int ndx;
   int min_index = 0;
   
   
   for (ndx = 0; ndx < size; ndx++) {
      if (people[ndx].birth_month < min_month || (people[ndx].birth_month == min_month 
                                                  && people[ndx].birth_day < min_day) ){
             min_month = people[ndx].birth_month;
             min_day = people[ndx].birth_day;
             min_index = ndx;
      }
      
   }
   
   return min_index;
}


int main() {
   FILE * file;
   FILE * output;
   int ndx = 0;
   int min_ndx;
   
   struct Person people[10];
   
   file = fopen("birthdays.txt", "r");
  
   while (fscanf(file, "%s", people[ndx].name) != EOF ) {
      fscanf(file, "%d", &people[ndx].birth_month);
      fscanf(file, "%d", &people[ndx].birth_day);
      ndx++;
   }
   
   min_ndx = find_min_bday(people, ndx);

   output = fopen("output.txt", "w");

   fprintf(output, "%s %d %d\n", people[min_ndx].name, 
           people[min_ndx].birth_month, 
           people[min_ndx].birth_day);

   fclose(output);
   fclose(file);

   return 0;
   
}
