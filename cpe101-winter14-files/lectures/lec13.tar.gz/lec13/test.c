#include <stdio.h>

int main() {
   FILE *fp;
   double num;
   char filename[] = "test.txt";

   fp = fopen(filename, "r");
   
   fscanf(fp, "%lf", &num);
   printf("%f\n", num);
   fscanf(fp, "%lf", &num);
   printf("%f\n", num);
   fclose(fp);

   return 0;

}
