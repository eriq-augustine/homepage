/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

void arr7() {
   int arr[10];
   int i;

   for (i = 1; i <= 10; i++) {
      arr[i - 1] = 3 * i;
   }

   for (i = 0; i < 10; i++) {
      printf("%d\n", arr[i]);
   }
}

void arr6() {
   int arr[10];
   int i;

   // Off by 1!
   // See arr7() for correct.
   for (i = 1; i < 10; i++) {
      arr[i] = 3 * i;
   }

   for (i = 0; i < 10; i++) {
      printf("%d\n", arr[i]);
   }
}

void arr5() {
   int arr[10];
   int i;

   for (i = 0; i < 10; i++) {
      arr[i] = 3 * (i + 1);
   }

   for (i = 0; i < 10; i++) {
      printf("%d\n", arr[i]);
   }
}

void arr4() {
   int arr[10];
   int i = 0;

   for (i = 0; i < 10; i++) {
      arr[i] = i;
   }

   for (i = 0; i < 10; i++) {
      printf("%d\n", arr[i]);
   }
}

void arr3() {
   int arr[10];
   int i = 0;

   for (i = 0; i < 10; i++) {
      arr[i] = 0;
   }

   for (i = 0; i < 10; i++) {
      printf("%d\n", arr[i]);
   }
}

void arr2() {
   int arr[10];

   // HEY! Don't go out of bounds!
   printf("%d\n", arr[-10]);
   printf("%d\n", arr[10]);
   printf("%d\n", arr[10000]);
}

void arr1() {
   int arr[10];

   printf("%d\n", arr[0]);

   arr[0] = 7;
   printf("%d\n", arr[0]);
}

int main(int argc, char *argv[])
{
   arr7();
   return EXIT_SUCCESS;
}
