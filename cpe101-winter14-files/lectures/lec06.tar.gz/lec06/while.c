/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

void loop6() {
   int a = 1;

   while (a > 0) {
      printf("%d\n", a);
      a++;
   }
}

void loop5() {
   char c = 'A';

   while (c <= 'z') {
      if (!(c > 'Z' && c < 'a')) {
         printf("%c\a\n", c);
      }
      c++;
   }
}

void loop4() {
   int a = -12;

   while (a < 10) {
      if (a % 3 == 0 && a != 0) {
         printf("%d\n", a);
      }
      a++;
   }
}

void loop3() {
   int a = 0;

   while (a < 10) {
      printf("%d\n", a);
      a += 2;
   }
}

void loop2() {
   int a = 0;

   while (a < 10) {
      if (a % 2 == 0) {
         printf("%d\n", a);
      }

      a++;
   }
}

void loop1() {
   int a = 0;

   while (a < 10) {
      printf("%d\n", a);
      a++;
   }
}

int main(int argc, char *argv[])
{
   loop6();

   return EXIT_SUCCESS;
}
