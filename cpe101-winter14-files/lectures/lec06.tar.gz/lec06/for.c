/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

void loop4() {
   int i;
   int j;

   for (i = 0; i < 20; i++) {
      for (j = 0; j < 20; j++) {
         if (i == j) {
            printf("x");
         } else {
            printf(" ");
         }
      }
      printf("\n");
   }
}

void loop3() {
   int a;
   for (a = 2; a > 0; a *= 2) {
      printf("%d\n", a);
   }

   printf("%d\n", a);
}

void loop2() {
   int a;
   for (a = 9; a >= 0; a--) {
      printf("%d\n", a);
   }
}

void loop1() {
   int a;
   for (a = 0; a < 10; a++) {
      printf("%d\n", a);
   }
}

int main(int argc, char *argv[])
{
   loop4();

   return EXIT_SUCCESS;
}
