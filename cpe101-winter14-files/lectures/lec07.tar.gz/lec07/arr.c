/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include <time.h>

#define SIZE 100

void printArr(int arr[SIZE]) {
   int i;
   for (i = 0; i < SIZE; i++) {
      printf("%d\n", arr[i]);
   }
}

void funArray() {
   int arr[SIZE];
   int i;

   for (i = 0; i < SIZE; i++) {
      arr[i] = (rand() % 100) + 1;
   }

   printArr(arr);
}

void findScore(int needle) {
   int arr[SIZE];
   int i;

   for (i = 0; i < SIZE; i++) {
      arr[i] = (rand() % 100) + 1;
   }

   for (i = 0; i < SIZE; i++) {
      if (arr[i] == needle) {
         printf("%d got a score of %d!\n", i, needle);
      }
   }
}

int gotScore(int needle) {
   int arr[SIZE];
   int i;

   for (i = 0; i < SIZE; i++) {
      arr[i] = (rand() % 100) + 1;
   }

   for (i = 0; i < SIZE; i++) {
      if (arr[i] == needle) {
         return 1;
      }
   }

   return 0;
}

int howManyGotScore(int needle) {
   int arr[SIZE];
   int i;
   int count = 0;

   for (i = 0; i < SIZE; i++) {
      arr[i] = (rand() % 100) + 1;
   }

   for (i = 0; i < SIZE; i++) {
      if (arr[i] == needle) {
         count++;
      }
   }

   return count;
}

void printUntil(int needle) {
   int arr[SIZE];
   int i;

   for (i = 0; i < SIZE; i++) {
      arr[i] = (rand() % 100) + 1;
   }

   for (i = 0; i < SIZE; i++) {
      if (arr[i] == needle) {
         break;
      }
   }

   printf("%d times\n", i);
}

int main(int argc, char *argv[])
{
   srand(time(NULL));
   // srand(8);

   // funArray();
   // findScore(100);

   /*
   if (gotScore(100)) {
      printf("Got the score!\n");
   }
   */

   //printf("%d people got the score.\n", howManyGotScore(100));

   printUntil(100);

   return EXIT_SUCCESS;
}
