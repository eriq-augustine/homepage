/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

void userInput() {
   int in;

   do {
      printf("Enter a non-negative number: ");

      // Get number from user.
      scanf("%d", &in);
   } while (in < 0);

   printf("Congrats!, you entered %d\n", in);
}

void loop() {
   int i = 0;

   do {
      printf("%d\n", i);
      i++;
   } while (i < 10);
}

int main(int argc, char *argv[])
{
   // loop();
   userInput();
   return EXIT_SUCCESS;
}
