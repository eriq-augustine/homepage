/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 10

void printArr(int arr[SIZE][SIZE]) {
   int row, col;

   for (row = 0; row < SIZE; row++) {
      for (col = 0; col < SIZE; col++) {
         printf("%8d", arr[row][col]);
      }
      printf("\n");
   }
}

void mul_table() {
   int row, col;

   int arr[SIZE][SIZE];

   for (row = 0; row < SIZE; row++) {
      for (col = 0; col < SIZE; col++) {
         arr[row][col] = row * col;
      }
   }

   printArr(arr);
}

void do_x_arr() {
   int row, col;

   int arr[SIZE][SIZE];

   for (row = 0; row < SIZE; row++) {
      for (col = 0; col < SIZE; col++) {
         if (row == col || row + col == SIZE - 1) {
            arr[row][col] = 7;
         } else {
            arr[row][col] = 0;
         }
      }
   }

   printArr(arr);
}

void do_x() {
   int row, col;

   for (row = 0; row < SIZE; row++) {
      for (col = 0; col < SIZE; col++) {
         if (row == col || row + col == SIZE - 1) {
            printf("X");
         } else {
            printf(" ");
         }
      }
      printf("\n");
   }
}

int main(int argc, char *argv[])
{
   // do_x();
   // mul_table();
   do_x_arr();
   return EXIT_SUCCESS;
}
