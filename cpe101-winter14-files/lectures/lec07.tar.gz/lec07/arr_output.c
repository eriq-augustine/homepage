/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define SIZE 10

int fillArray(int arr[]) {
   int i;

   for (i = 0; i < SIZE; i++) {
      arr[i] = i;
   }
}

int main(int argc, char *argv[]) {
   int some_array[10];
   int i;

   for (i = 0; i < SIZE; i++) {
      printf("%d, ", some_array[i]);
   }
   printf("\n");

   fillArray(some_array);

   for (i = 0; i < SIZE; i++) {
      printf("%d, ", some_array[i]);
   }
   printf("\n");

   return EXIT_SUCCESS;
}
