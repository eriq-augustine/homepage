/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#define MAX_SIZE 15

// Odd indexes
int filter02(int arr[], int size, int res[]) {
   int count = 0;

   int i;
   for (i = 0; i < size; i++) {
      if (i % 2 == 1) {
         res[count] = arr[i];
         count++;
      }
   }

   return count;
}

// Even numbers
int filter01(int arr[], int size, int res[]) {
   int count = 0;

   int i;
   for (i = 0; i < size; i++) {
      if (arr[i] % 2 == 0) {
         res[count] = arr[i];
         count++;
      }
   }

   return count;
}

// Divisible by three thing.
void map02(int arr[], int size) {
   int i;
   for (i = 0; i < size; i++) {
      if (arr[i] % 3 == 0) {
         arr[i] = 0;
      } else {
         arr[i] = 1;
      }
   }
}

// Square each number.
void map01(int arr[], int size) {
   int i;
   for (i = 0; i < size; i++) {
      arr[i] = pow(arr[i], 2);
   }
}

void fill_array(int arr[], int size) {
   int i;
   for (i = 0; i < size; i++) {
      arr[i] = i;
   }
}

void print_arr(int arr[], int size) {
   int i;
   for (i = 0; i < size; i++) {
      printf("%d, ", arr[i]);
   }
   printf("\n");
}

int main(int argc, char *argv[])
{
   int somearr[MAX_SIZE];
   int wintarr[MAX_SIZE];

   fill_array(somearr, 10);
   print_arr(somearr, 10);

   fill_array(wintarr, MAX_SIZE);

   map01(somearr, 10);
   print_arr(somearr, 10);

   map02(wintarr, MAX_SIZE);
   print_arr(wintarr, MAX_SIZE);

   int snowcones[MAX_SIZE];
   fill_array(wintarr, MAX_SIZE);
   int count_s = filter01(wintarr, MAX_SIZE, snowcones);
   printf("|snowcones| = %d\n", count_s);
   print_arr(snowcones, count_s);
   print_arr(snowcones, MAX_SIZE);

   fill_array(wintarr, MAX_SIZE);
   count_s = filter02(wintarr, MAX_SIZE, snowcones);
   printf("|snowcones| = %d\n", count_s);
   print_arr(snowcones, count_s);

   return EXIT_SUCCESS;
}
