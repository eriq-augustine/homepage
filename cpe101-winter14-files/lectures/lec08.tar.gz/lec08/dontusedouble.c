/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "checkit.h"

int main(int argc, char *argv[])
{
   double my_money = 100.50;
   double some_money = 10;

   some_money += 30;
   some_money *= 2.1;
   some_money /= 2.1;
   some_money *= 2.0;
   some_money += 10;
   some_money += 1.10;
   some_money += 0.40;
   some_money += 9;

   checkit_double(my_money, some_money);
   if (my_money != some_money) {
      printf("Different!\n");
   }

   return EXIT_SUCCESS;
}
