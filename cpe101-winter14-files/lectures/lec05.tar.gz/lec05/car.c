/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "car.h"

struct engine create_engine(int c, double d, int h) {
   struct engine eng;
   eng.cylinders = c;
   eng.disp = d;
   eng.horsepower = h;
   return eng;
}

struct car create_car(int w, double m, int c, struct engine eng, double max_gas) {
   struct car my_car;
   my_car.wheels = w;
   my_car.capacity = c;
   my_car.mpg = m;
   my_car.engy = eng;
   my_car.max_gas = max_gas;
   my_car.gas = 0;
   return my_car;
}

struct car tune_up(struct car lambo) {
   lambo.engy.horsepower = lambo.engy.horsepower * 1.5;
   return lambo;
}

int is_more_powerful(struct car car_1, struct car car_2){
   return car_1.engy.horsepower > car_2.engy.horsepower;
}

struct car drive(struct car my_car, double dist) {
   double gas_used = dist / my_car.mpg;

   if (my_car.gas == 0 || dist < 0)
   {
      return my_car;
   }
   else if (gas_used > my_car.gas)
   {
      printf("Go to gas station, you jerk!\n");
      my_car.gas = 0;
   }
   else
   {
      my_car.gas -= gas_used;
   }

   return my_car;
}

struct car fill_up(struct car my_car, double gas_cost,
                   double gallons_fill) {
   my_car.gas += gallons_fill;

   if (my_car.gas > my_car.max_gas)
   {
      my_car.gas = my_car.max_gas;
   }

   return my_car;

}
