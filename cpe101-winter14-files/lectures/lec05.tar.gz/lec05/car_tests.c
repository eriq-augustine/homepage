/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "car.h"
#include "checkit.h"

void test_cases() {
   struct engine v8 = create_engine(8, 6, 30);
   struct engine v6 = create_engine(6, 4, 20);

   checkit_int(v8.horsepower > v6.horsepower, 1);

   struct car lambo = create_car(4, 15, 2, create_engine(12, 8, 300), 10);
   checkit_int(lambo.engy.horsepower, 300);

   lambo = tune_up(lambo);
   checkit_int(lambo.engy.horsepower > 300, 1);

   checkit_int(is_more_powerful(lambo, create_car(5, 25, 5, create_engine(12, -1, 2), 10)), 1);
}

void gas_test_cases() {
   struct car steve = create_car(4, 33, 5, create_engine(12, 1, 4), 10);
   steve = fill_up(steve, 100, 10);

   checkit_double(steve.gas, 10.0);
   steve = drive(steve, 33);
   checkit_double(steve.gas, 9.0);

   steve = drive(steve, 33321);
   checkit_double(steve.gas, 0);

   steve = drive(steve, 1);
   checkit_double(steve.gas, 0);

   steve = fill_up(steve, 100, 0.1);
   steve = drive(steve, -100);
   checkit_double(steve.gas, 0.1);
}

int main(int argc, char *argv[])
{
   // test_cases();
   gas_test_cases();
   return EXIT_SUCCESS;
}
