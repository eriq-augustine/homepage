#ifndef CAR_H
#define CAR_H


struct engine {
   int cylinders;
   double disp;
   int horsepower;
};

struct car {
   int wheels;
   double mpg;
   int capacity;

   double gas;
   double max_gas;

   struct engine engy;
};

struct engine create_engine(int, double, int);
struct car create_car(int, double, int, struct engine, double max_gas);

struct car tune_up(struct car);

int is_more_powerful(struct car car_1, struct car car_2);

struct car drive(struct car my_car, double dist);
struct car fill_up(struct car my_car, double gas_cost, double gallons_fill);

#endif
