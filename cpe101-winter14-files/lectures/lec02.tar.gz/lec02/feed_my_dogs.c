/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

#include "dogs.h"

struct dog feed_dog(struct dog to_feed) {
   // to_feed.mass = to_feed.mass + 5;
   to_feed.mass += 5;

   return to_feed;
}

/*
int main()
{
   printf("This Main!\n");
}
*/
