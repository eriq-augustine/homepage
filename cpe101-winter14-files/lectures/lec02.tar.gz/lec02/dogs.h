struct dog {
   int legs;
   int eyes;
   char color;
   double mass;
};

struct dog create_dog(int legs, int eyes, char color,
                      double mass);

struct dog feed_dog(struct dog);
