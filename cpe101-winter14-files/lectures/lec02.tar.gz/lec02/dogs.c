/**
 *  @author Eric Augustine 
 */

#include "checkit.h"
#include "dogs.h"

int
main(int argc, char *argv[])
{
   struct dog cool_dog = create_dog(4, 7, 'b', 20);

   checkit_int(cool_dog.legs, 4);
   checkit_int(cool_dog.eyes, 7);
   checkit_char(cool_dog.color, 'b');
   checkit_double(cool_dog.mass, 20);

   cool_dog = feed_dog(cool_dog);
   checkit_double(cool_dog.mass, 20 + 5);

   return 0;
}

struct dog create_dog(int legs, int eyes, char color,
                      double mass)
{
   struct dog my_dog;
   my_dog.legs = legs;
   my_dog.eyes = eyes;
   my_dog.color = color;
   my_dog.mass = mass;

   return my_dog;
}
