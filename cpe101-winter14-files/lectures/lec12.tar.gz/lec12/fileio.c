/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

void read_int_from_file() {
   FILE* my_file;
   int num;

   my_file = fopen("myFile.txt", "r");
   fscanf(my_file, "%d", &num);
   fclose(my_file);

   printf("My Number: %d\n", num);
}

int main(int argc, char *argv[])
{
   read_int_from_file();
   return EXIT_SUCCESS;
}
