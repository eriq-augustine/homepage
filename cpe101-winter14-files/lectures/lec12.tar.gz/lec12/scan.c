/**
 *  @author Eric Augustine 
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

void get_int_char() {
   int some_int;
   char some_char;

   scanf("%d %c", &some_int, &some_char);

   printf("Int: %d, Char: %c\n", some_int, some_char);
}

void get_int_double() {
   int some_int;
   double some_double;

   scanf("%d %lf", &some_int, &some_double);

   printf("Int: %d, Double: %f\n", some_int, some_double);
}

int get_positive_int() {
   int num = 0;
   int result;
   char garbage;

   do {
      printf("Give me an int plz: ");
      result = scanf("%d", &num);

      if (result == 0) {
         result = scanf("%c", &garbage);

         /*
         do {
            // Doesn't work, consumes the ints.
            result = scanf("%c", &garbage);
         } while (result == 1);
         */

         printf("ya stupid idiot!\n");
      }
   } while (num <= 0);

   return num;
}

int get_int() {
   int num;

   printf("Give me an int plz: ");
   // Don't FORGET the '&'.
   scanf("%d", &num);

   return num;
}

double get_double() {
   double num;

   printf("Give me a double plz: ");
   // Don't FORGET the '&'.
   scanf("%lf", &num);

   return num;
}
int main(int argc, char *argv[])
{
   /*
   int some_int;

   some_int = get_int();
   printf("Some Int0: %d\n", some_int);

   some_int = get_int();
   printf("Some Int1: %d\n", some_int);
   */

   /*
   double some_double;

   some_double = get_double();
   printf("Some Int0: %f\n", some_double);

   some_double = get_double();
   printf("Some Int1: %f\n", some_double);
   */

   /*
   int some_int;

   some_int = get_positive_int();
   printf("Some Int0: %d\n", some_int);
   */

   // get_int_double();
   get_int_char();

   return EXIT_SUCCESS;
}
